--
-- PostgreSQL database dump
--

\restrict jpnQ70rIrJsc8zlNp1kupkjPajocqWfJIuR6XdxpgwIkDbtsvDLN6IftQxM1nch

-- Dumped from database version 17.6
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO supabase_admin;

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO pgbouncer;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO supabase_admin;

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO supabase_admin;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE auth.oauth_authorization_status OWNER TO supabase_auth_admin;

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE auth.oauth_client_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE auth.oauth_registration_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


ALTER TYPE auth.oauth_response_type OWNER TO supabase_auth_admin;

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO supabase_auth_admin;

--
-- Name: BedStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BedStatus" AS ENUM (
    'AVAILABLE',
    'OCCUPIED',
    'MAINTENANCE'
);


ALTER TYPE public."BedStatus" OWNER TO postgres;

--
-- Name: BillingStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BillingStatus" AS ENUM (
    'PENDING',
    'INVOICED',
    'WAIVED',
    'CANCELLED'
);


ALTER TYPE public."BillingStatus" OWNER TO postgres;

--
-- Name: BloodGroup; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BloodGroup" AS ENUM (
    'A_POSITIVE',
    'A_NEGATIVE',
    'B_POSITIVE',
    'B_NEGATIVE',
    'AB_POSITIVE',
    'AB_NEGATIVE',
    'O_POSITIVE',
    'O_NEGATIVE'
);


ALTER TYPE public."BloodGroup" OWNER TO postgres;

--
-- Name: ChargeSourceModule; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ChargeSourceModule" AS ENUM (
    'OPD',
    'IPD',
    'OT',
    'LABORATORY',
    'RADIOLOGY',
    'PHARMACY',
    'MANUAL'
);


ALTER TYPE public."ChargeSourceModule" OWNER TO postgres;

--
-- Name: DeathLocationType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DeathLocationType" AS ENUM (
    'EMERGENCY',
    'IPD',
    'DEAD_ON_ARRIVAL'
);


ALTER TYPE public."DeathLocationType" OWNER TO postgres;

--
-- Name: DeliveryType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DeliveryType" AS ENUM (
    'NORMAL',
    'CESAREAN',
    'STILL_BIRTH'
);


ALTER TYPE public."DeliveryType" OWNER TO postgres;

--
-- Name: EmployeeRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EmployeeRole" AS ENUM (
    'SUPER_ADMIN',
    'HOSPITAL_ADMIN',
    'EMPLOYEE'
);


ALTER TYPE public."EmployeeRole" OWNER TO postgres;

--
-- Name: Gender; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Gender" AS ENUM (
    'MALE',
    'FEMALE',
    'OTHER'
);


ALTER TYPE public."Gender" OWNER TO postgres;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'PENDING',
    'PAID',
    'PARTIALLY_PAID',
    'CANCELLED',
    'REFUNDED'
);


ALTER TYPE public."InvoiceStatus" OWNER TO postgres;

--
-- Name: LaboratoryStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."LaboratoryStatus" AS ENUM (
    'SCHEDULED',
    'SAMPLE_COLLECTED',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."LaboratoryStatus" OWNER TO postgres;

--
-- Name: MaritalStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."MaritalStatus" AS ENUM (
    'SINGLE',
    'MARRIED',
    'DIVORCED',
    'WIDOWED'
);


ALTER TYPE public."MaritalStatus" OWNER TO postgres;

--
-- Name: OTType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."OTType" AS ENUM (
    'MINOR',
    'MAJOR'
);


ALTER TYPE public."OTType" OWNER TO postgres;

--
-- Name: PaymentMode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PaymentMode" AS ENUM (
    'CASH',
    'UPI',
    'CARD',
    'CHEQUE',
    'BANK_TRANSFER'
);


ALTER TYPE public."PaymentMode" OWNER TO postgres;

--
-- Name: PharmacyAdjustmentType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PharmacyAdjustmentType" AS ENUM (
    'DAMAGED',
    'EXPIRED',
    'LOST',
    'MANUAL_CORRECTION'
);


ALTER TYPE public."PharmacyAdjustmentType" OWNER TO postgres;

--
-- Name: PharmacyCustomerType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PharmacyCustomerType" AS ENUM (
    'WALK_IN',
    'PATIENT'
);


ALTER TYPE public."PharmacyCustomerType" OWNER TO postgres;

--
-- Name: PrintTemplateStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PrintTemplateStatus" AS ENUM (
    'DRAFT',
    'PUBLISHED',
    'ARCHIVED'
);


ALTER TYPE public."PrintTemplateStatus" OWNER TO postgres;

--
-- Name: RadiologyStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RadiologyStatus" AS ENUM (
    'SCHEDULED',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."RadiologyStatus" OWNER TO postgres;

--
-- Name: RoomType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RoomType" AS ENUM (
    'GENERAL_WARD',
    'ICU',
    'SEMI_PRIVATE',
    'PRIVATE'
);


ALTER TYPE public."RoomType" OWNER TO postgres;

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE realtime.action OWNER TO supabase_admin;

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


ALTER TYPE realtime.equality_op OWNER TO supabase_admin;

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


ALTER TYPE realtime.user_defined_filter OWNER TO supabase_admin;

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


ALTER TYPE realtime.wal_column OWNER TO supabase_admin;

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


ALTER TYPE realtime.wal_rls OWNER TO supabase_admin;

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE storage.buckettype OWNER TO supabase_storage_admin;

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
begin
    if not exists (
        select 1
        from pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: supabase_admin
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


ALTER FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) OWNER TO supabase_admin;

--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO supabase_admin;

--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) OWNER TO supabase_admin;

--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) OWNER TO supabase_admin;

--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) OWNER TO supabase_admin;

--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION realtime."cast"(val text, type_ regtype) OWNER TO supabase_admin;

--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) OWNER TO supabase_admin;

--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
/*
Should the record be visible (true) or filtered out (false) after *filters* are applied
*/
    select
        -- Default to allowed when no filters present
        $2 is null -- no filters. this should not happen because subscriptions has a default
        or array_length($2, 1) is null -- array length of an empty array is null
        or bool_and(
            coalesce(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(
                        col.type_oid::regtype, -- null when wal2json version <= 2.4
                        col.type_name::regtype
                    ),
                    -- cast jsonb to text
                    val_1:=col.value #>> '{}',
                    val_2:=f.value
                ),
                false -- if null, filter does not match
            )
        )
    from
        unnest(filters) f
        join unnest(columns) col
            on f.column_name = col.name;
$_$;


ALTER FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) OWNER TO supabase_admin;

--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS TABLE(wal jsonb, is_rls_enabled boolean, subscription_ids uuid[], errors text[], slot_changes_count bigint)
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


ALTER FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) OWNER TO supabase_admin;

--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


ALTER FUNCTION realtime.quote_wal2json(entity regclass) OWNER TO supabase_admin;

--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) OWNER TO supabase_admin;

--
-- Name: send_binary(bytea, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) OWNER TO supabase_admin;

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        else
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


ALTER FUNCTION realtime.subscription_check_filters() OWNER TO supabase_admin;

--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION realtime.to_regrole(role_name text) OWNER TO supabase_admin;

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION realtime.topic() OWNER TO supabase_realtime_admin;

--
-- Name: wal2json_escape_identifier(text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.wal2json_escape_identifier(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


ALTER FUNCTION realtime.wal2json_escape_identifier(name text) OWNER TO supabase_admin;

--
-- Name: allow_any_operation(text[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.allow_any_operation(expected_operations text[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION storage.allow_any_operation(expected_operations text[]) OWNER TO supabase_storage_admin;

--
-- Name: allow_only_operation(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.allow_only_operation(expected_operation text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION storage.allow_only_operation(expected_operation text) OWNER TO supabase_storage_admin;

--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION storage.enforce_bucket_name_length() OWNER TO supabase_storage_admin;

--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_common_prefix(text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) OWNER TO supabase_storage_admin;

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO supabase_storage_admin;

--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text) OWNER TO supabase_storage_admin;

--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text, sort_order text) OWNER TO supabase_storage_admin;

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION storage.operation() OWNER TO supabase_storage_admin;

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.protect_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.protect_delete() OWNER TO supabase_storage_admin;

--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: search_by_timestamp(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) OWNER TO supabase_storage_admin;

--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer, levels integer, start_after text, sort_order text, sort_column text, sort_column_after text) OWNER TO supabase_storage_admin;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    custom_claims_allowlist text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


ALTER TABLE auth.custom_oauth_providers OWNER TO supabase_auth_admin;

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


ALTER TABLE auth.oauth_authorizations OWNER TO supabase_auth_admin;

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE auth.oauth_client_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


ALTER TABLE auth.oauth_clients OWNER TO supabase_auth_admin;

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


ALTER TABLE auth.oauth_consents OWNER TO supabase_auth_admin;

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


ALTER TABLE auth.webauthn_challenges OWNER TO supabase_auth_admin;

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


ALTER TABLE auth.webauthn_credentials OWNER TO supabase_auth_admin;

--
-- Name: audits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audits (
    id text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "userId" text,
    "clientIp" character varying(45),
    action character varying(50) NOT NULL,
    resource character varying(100),
    "entityId" uuid,
    "requestId" character varying(50),
    "previousState" jsonb,
    "newState" jsonb,
    reason text,
    description text NOT NULL
);


ALTER TABLE public.audits OWNER TO postgres;

--
-- Name: bed_rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bed_rooms (
    id text NOT NULL,
    "roomNumber" character varying(20) NOT NULL,
    "roomType" public."RoomType" NOT NULL,
    "chargePerDay" numeric(12,2) NOT NULL,
    "wardId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.bed_rooms OWNER TO postgres;

--
-- Name: bed_transfer_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bed_transfer_history (
    id text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    "previousBedId" text,
    "newBedId" text NOT NULL,
    "transferDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "transferReason" text,
    "transferredBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.bed_transfer_history OWNER TO postgres;

--
-- Name: beds; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.beds (
    id text NOT NULL,
    "roomId" text NOT NULL,
    "bedNumber" character varying(20) NOT NULL,
    status public."BedStatus" DEFAULT 'AVAILABLE'::public."BedStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.beds OWNER TO postgres;

--
-- Name: billable_charges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.billable_charges (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "chargeCatalogId" text NOT NULL,
    "sourceModule" public."ChargeSourceModule" NOT NULL,
    "sourceEntityId" uuid NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    rate numeric(12,2) NOT NULL,
    "totalAmount" numeric(12,2) NOT NULL,
    "billingStatus" public."BillingStatus" DEFAULT 'PENDING'::public."BillingStatus" NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.billable_charges OWNER TO postgres;

--
-- Name: birth_registrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.birth_registrations (
    id text NOT NULL,
    "babyName" character varying(150),
    dob timestamp(3) without time zone NOT NULL,
    gender public."Gender" NOT NULL,
    "weightKg" numeric(5,2) NOT NULL,
    "motherPatientId" text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    "hospitalId" text NOT NULL,
    "deliveryType" public."DeliveryType" NOT NULL,
    "attendingDoctorId" text NOT NULL,
    "certificateNumber" character varying(50) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.birth_registrations OWNER TO postgres;

--
-- Name: buildings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.buildings (
    id text NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(20) NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.buildings OWNER TO postgres;

--
-- Name: charge_catalogs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.charge_catalogs (
    id text NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(150) NOT NULL,
    category character varying(50) NOT NULL,
    rate numeric(12,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid,
    "otType" public."OTType"
);


ALTER TABLE public.charge_catalogs OWNER TO postgres;

--
-- Name: death_registrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.death_registrations (
    id text NOT NULL,
    "patientId" text,
    "ipdAdmissionId" text,
    "hospitalId" text NOT NULL,
    "deceasedName" character varying(150) NOT NULL,
    "deceasedAge" integer NOT NULL,
    "deceasedGender" public."Gender" NOT NULL,
    "dateOfDeath" timestamp(3) without time zone NOT NULL,
    "causeOfDeath" text NOT NULL,
    "locationType" public."DeathLocationType" NOT NULL,
    "attendingDoctorId" text,
    "informantDetails" text,
    "certificateNumber" character varying(50) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.death_registrations OWNER TO postgres;

--
-- Name: departments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departments (
    id text NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(10) NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.departments OWNER TO postgres;

--
-- Name: discharge_summary_revisions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discharge_summary_revisions (
    id text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    "revisionNumber" integer NOT NULL,
    summary text NOT NULL,
    "editedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "editedBy" text NOT NULL
);


ALTER TABLE public.discharge_summary_revisions OWNER TO postgres;

--
-- Name: doctor_assignment_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctor_assignment_history (
    id text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    "previousDoctorId" text,
    "assignedDoctorId" text NOT NULL,
    "effectiveFrom" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "effectiveTo" timestamp(3) without time zone,
    "changedBy" text NOT NULL,
    reason text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.doctor_assignment_history OWNER TO postgres;

--
-- Name: doctors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctors (
    id text NOT NULL,
    "registrationNumber" character varying(50) NOT NULL,
    qualification character varying(150) NOT NULL,
    specialization character varying(100) NOT NULL,
    "consultationFee" numeric(12,2) NOT NULL,
    "roomNumber" character varying(20),
    "dutySchedule" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.doctors OWNER TO postgres;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    id text NOT NULL,
    name character varying(100) DEFAULT 'Employee'::character varying NOT NULL,
    "employeeCode" character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    "passwordHash" character varying(255) NOT NULL,
    role public."EmployeeRole" NOT NULL,
    designation character varying(100) NOT NULL,
    "departmentId" text,
    "hospitalId" text NOT NULL,
    "mobileNumber" character varying(20) NOT NULL,
    "joiningDate" timestamp(3) without time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "failedLoginCount" integer DEFAULT 0 NOT NULL,
    "lockedUntil" timestamp(3) without time zone,
    "passwordChangedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastLoginAt" timestamp(3) without time zone,
    "lastLoginIp" character varying(45),
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Name: floors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.floors (
    id text NOT NULL,
    name character varying(100) NOT NULL,
    "buildingId" text NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.floors OWNER TO postgres;

--
-- Name: hospitals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hospitals (
    id text NOT NULL,
    name character varying(150) NOT NULL,
    code character varying(10) NOT NULL,
    phone character varying(20) NOT NULL,
    email character varying(100) NOT NULL,
    address text NOT NULL,
    "gstNumber" character varying(50),
    "registrationNumber" character varying(100),
    website character varying(150),
    "logoUrl" text,
    "footerText" text,
    "stateInsuranceLicense" character varying(100),
    "currentVersion" character varying(20) DEFAULT '2.0.0'::character varying NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.hospitals OWNER TO postgres;

--
-- Name: invoice_charge_mappings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_charge_mappings (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    "billableChargeId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.invoice_charge_mappings OWNER TO postgres;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    "invoiceNumber" character varying(30) NOT NULL,
    "patientId" text NOT NULL,
    "hospitalId" text NOT NULL,
    "totalAmount" numeric(12,2) NOT NULL,
    "discountAmount" numeric(12,2) DEFAULT 0.00 NOT NULL,
    "discountPercentage" numeric(5,2),
    "discountReason" text,
    "discountApprovedBy" uuid,
    "payableAmount" numeric(12,2) NOT NULL,
    "paidAmount" numeric(12,2) DEFAULT 0.00 NOT NULL,
    "balanceAmount" numeric(12,2) NOT NULL,
    "paymentStatus" public."InvoiceStatus" DEFAULT 'PENDING'::public."InvoiceStatus" NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "cancelledBy" text,
    "cancellationReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: ipd_admissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipd_admissions (
    id text NOT NULL,
    "ipdId" character varying(30) NOT NULL,
    "patientId" text NOT NULL,
    "bedId" text NOT NULL,
    "primaryDoctorId" text NOT NULL,
    "departmentId" text NOT NULL,
    "hospitalId" text NOT NULL,
    "admissionDate" timestamp(3) without time zone NOT NULL,
    "dischargeDate" timestamp(3) without time zone,
    "dischargeSummary" text,
    "dischargeBy" text,
    "isDeceased" boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "codeStatus" text DEFAULT 'FULL_CODE'::text,
    "isolationStatus" text DEFAULT 'NONE'::text,
    "referredByDoctorId" text,
    "isMLC" boolean DEFAULT false NOT NULL,
    "mlcNumber" text,
    "admissionSource" text,
    "admissionCategory" text DEFAULT 'GENERAL'::text,
    "initialDepositRequired" double precision DEFAULT 0,
    "admissionReason" text,
    status text DEFAULT 'ADMITTED'::text NOT NULL,
    "dischargeType" text,
    "finalDiagnosis" text,
    "treatmentSummary" text,
    "conditionAtDischarge" text,
    "followUpInstructions" text,
    "cancelledAt" timestamp(3) without time zone,
    "cancelledBy" text,
    "cancellationReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.ipd_admissions OWNER TO postgres;

--
-- Name: ipd_attendants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipd_attendants (
    id text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    name text NOT NULL,
    relationship text NOT NULL,
    mobile text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ipd_attendants OWNER TO postgres;

--
-- Name: ipd_clinical_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipd_clinical_attachments (
    id text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    "documentType" text NOT NULL,
    "fileUrl" text NOT NULL,
    description text,
    "recordedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ipd_clinical_attachments OWNER TO postgres;

--
-- Name: ipd_consultations_clinical; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipd_consultations_clinical (
    id text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    "targetDepartmentId" text NOT NULL,
    "targetDoctorId" text,
    reason text NOT NULL,
    urgency text DEFAULT 'ROUTINE'::text NOT NULL,
    status text DEFAULT 'REQUESTED'::text NOT NULL,
    "completionNotes" text,
    "recordedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ipd_consultations_clinical OWNER TO postgres;

--
-- Name: ipd_doctor_rounds; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipd_doctor_rounds (
    id text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    "doctorId" text NOT NULL,
    condition text NOT NULL,
    findings text NOT NULL,
    recommendations text NOT NULL,
    "recordedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ipd_doctor_rounds OWNER TO postgres;

--
-- Name: ipd_handovers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipd_handovers (
    id text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    "recipientUserId" text NOT NULL,
    "conditionSummary" text NOT NULL,
    checklist text NOT NULL,
    remarks text,
    "recordedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ipd_handovers OWNER TO postgres;

--
-- Name: ipd_intake_output; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipd_intake_output (
    id text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    "intakeMl" integer,
    "intakeType" text,
    "outputMl" integer,
    "outputType" text,
    remarks text,
    "recordedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ipd_intake_output OWNER TO postgres;

--
-- Name: ipd_nursing_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipd_nursing_tasks (
    id text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    description text NOT NULL,
    "scheduledTime" timestamp(3) without time zone NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "recordedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ipd_nursing_tasks OWNER TO postgres;

--
-- Name: ipd_progress_notes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipd_progress_notes (
    id text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    "noteType" text NOT NULL,
    content text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "isAmended" boolean DEFAULT false NOT NULL,
    "amendmentReason" text,
    "parentNoteId" text,
    "recordedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ipd_progress_notes OWNER TO postgres;

--
-- Name: ipd_timeline_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipd_timeline_events (
    id text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    "eventType" text NOT NULL,
    description text NOT NULL,
    "recordedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.ipd_timeline_events OWNER TO postgres;

--
-- Name: ipd_treatment_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipd_treatment_orders (
    id text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    "orderType" text NOT NULL,
    priority text DEFAULT 'ROUTINE'::text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "isVerified" boolean DEFAULT false NOT NULL,
    "verifiedBy" text,
    "verifiedAt" timestamp(3) without time zone,
    "recordedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ipd_treatment_orders OWNER TO postgres;

--
-- Name: ipd_vitals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ipd_vitals (
    id text NOT NULL,
    "ipdAdmissionId" text NOT NULL,
    temperature double precision,
    pulse integer,
    "systolicBP" integer,
    "diastolicBP" integer,
    spo2 integer,
    "respiratoryRate" integer,
    weight double precision,
    height double precision,
    "bloodSugar" integer,
    "recordedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ipd_vitals OWNER TO postgres;

--
-- Name: lab_result_revisions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lab_result_revisions (
    id text NOT NULL,
    "testOrderId" text NOT NULL,
    "revisionNumber" integer NOT NULL,
    results jsonb NOT NULL,
    remarks text,
    "technicianId" uuid,
    "verifiedById" uuid,
    "completedAt" timestamp(3) without time zone NOT NULL,
    "completedBy" text NOT NULL,
    "editedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "editedBy" uuid NOT NULL
);


ALTER TABLE public.lab_result_revisions OWNER TO postgres;

--
-- Name: lab_test_catalogs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lab_test_catalogs (
    id text NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(150) NOT NULL,
    category character varying(50) NOT NULL,
    "standardRate" numeric(12,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.lab_test_catalogs OWNER TO postgres;

--
-- Name: lab_test_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lab_test_orders (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "testCatalogId" text NOT NULL,
    "orderedByDoctorId" text NOT NULL,
    "opdConsultationId" text,
    "ipdAdmissionId" text,
    "billableChargeId" text,
    "hospitalId" text NOT NULL,
    status public."LaboratoryStatus" DEFAULT 'SCHEDULED'::public."LaboratoryStatus" NOT NULL,
    "sampleCollectedAt" timestamp(3) without time zone,
    "sampleCollectedBy" uuid,
    "cancelledAt" timestamp(3) without time zone,
    "cancelledBy" uuid,
    "cancellationReason" text,
    "technicianId" uuid,
    "verifiedById" uuid,
    remarks text,
    "completedAt" timestamp(3) without time zone,
    "completedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.lab_test_orders OWNER TO postgres;

--
-- Name: lab_test_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lab_test_results (
    id text NOT NULL,
    "testOrderId" text NOT NULL,
    "parameterName" character varying(100) NOT NULL,
    "parameterValue" character varying(100) NOT NULL,
    "referenceRange" character varying(100),
    unit character varying(20),
    status character varying(30) DEFAULT 'DRAFT'::character varying NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.lab_test_results OWNER TO postgres;

--
-- Name: medicine_stocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medicine_stocks (
    id text NOT NULL,
    "medicineId" text NOT NULL,
    "batchNumber" character varying(50) NOT NULL,
    "expiryDate" date,
    "currentQuantity" integer NOT NULL,
    "purchaseRate" numeric(12,2) NOT NULL,
    "sellingRate" numeric(12,2) NOT NULL,
    "gstPercentage" numeric(5,2) DEFAULT 0.00 NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.medicine_stocks OWNER TO postgres;

--
-- Name: medicines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medicines (
    id text NOT NULL,
    code character varying(30) NOT NULL,
    name character varying(150) NOT NULL,
    "genericName" character varying(150) NOT NULL,
    category character varying(50) NOT NULL,
    form character varying(50) NOT NULL,
    "standardSellingPrice" numeric(12,2) NOT NULL,
    brand character varying(100) DEFAULT 'Generic'::character varying NOT NULL,
    unit character varying(30) DEFAULT 'Tablets'::character varying NOT NULL,
    "hsnCode" character varying(30),
    "gstPercentage" numeric(5,2) DEFAULT 0.00 NOT NULL,
    "purchasePrice" numeric(12,2) DEFAULT 0.00 NOT NULL,
    "sellingPrice" numeric(12,2) DEFAULT 0.00 NOT NULL,
    "minimumStock" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isExpirable" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.medicines OWNER TO postgres;

--
-- Name: opd_consultations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.opd_consultations (
    id text NOT NULL,
    "opdId" character varying(30) NOT NULL,
    "patientId" text NOT NULL,
    "doctorId" text NOT NULL,
    "departmentId" text NOT NULL,
    "hospitalId" text NOT NULL,
    "consultationDate" timestamp(3) without time zone NOT NULL,
    "depositAmount" numeric(12,2) DEFAULT 0.00 NOT NULL,
    "originalFee" numeric(12,2) NOT NULL,
    "appliedFee" numeric(12,2) NOT NULL,
    "overrideReason" text,
    "tokenNumber" integer NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    symptoms text,
    "cancelledAt" timestamp(3) without time zone,
    "cancelledBy" text,
    "cancellationReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.opd_consultations OWNER TO postgres;

--
-- Name: operation_theater_revisions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.operation_theater_revisions (
    id text NOT NULL,
    "operationTheaterId" text NOT NULL,
    "revisionNumber" integer NOT NULL,
    "operationName" character varying(150) NOT NULL,
    diagnosis text NOT NULL,
    "primarySurgeonId" text NOT NULL,
    "assistantSurgeonId" text,
    "departmentId" text NOT NULL,
    remarks text,
    "editedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "editedBy" text NOT NULL
);


ALTER TABLE public.operation_theater_revisions OWNER TO postgres;

--
-- Name: operation_theaters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.operation_theaters (
    id text NOT NULL,
    "otId" character varying(30) NOT NULL,
    "ipdAdmissionId" text,
    "opdConsultationId" text,
    "patientId" text NOT NULL,
    "hospitalId" text NOT NULL,
    "departmentId" text NOT NULL,
    "operationType" public."OTType" NOT NULL,
    "operationName" character varying(150) NOT NULL,
    diagnosis text NOT NULL,
    "scheduledDate" timestamp(3) without time zone NOT NULL,
    remarks text,
    "completedAt" timestamp(3) without time zone,
    "completedBy" text,
    "cancelledAt" timestamp(3) without time zone,
    "cancelledBy" text,
    "cancellationReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid,
    "primarySurgeonId" text NOT NULL,
    "assistantSurgeonId" text,
    "procedureCatalogId" text
);


ALTER TABLE public.operation_theaters OWNER TO postgres;

--
-- Name: patient_addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_addresses (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "addressLine" text NOT NULL,
    city character varying(100) NOT NULL,
    state character varying(100) NOT NULL,
    pincode character varying(15) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.patient_addresses OWNER TO postgres;

--
-- Name: patient_deposit_allocations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_deposit_allocations (
    id text NOT NULL,
    "depositId" text NOT NULL,
    "invoiceId" text NOT NULL,
    "amountAllocated" numeric(12,2) NOT NULL,
    "transactionDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.patient_deposit_allocations OWNER TO postgres;

--
-- Name: patient_deposits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_deposits (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "hospitalId" text NOT NULL,
    "opdConsultationId" text,
    amount numeric(12,2) NOT NULL,
    "collectedBy" uuid NOT NULL,
    "transactionDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isRefunded" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.patient_deposits OWNER TO postgres;

--
-- Name: patient_emergency_contacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_emergency_contacts (
    id text NOT NULL,
    "patientId" text NOT NULL,
    name character varying(150) NOT NULL,
    phone character varying(20) NOT NULL,
    relation character varying(50) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.patient_emergency_contacts OWNER TO postgres;

--
-- Name: patient_referrals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_referrals (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "referralType" character varying(50) NOT NULL,
    "referralName" character varying(150) NOT NULL,
    "referralNotes" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.patient_referrals OWNER TO postgres;

--
-- Name: patients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patients (
    id text NOT NULL,
    uhid character varying(30) NOT NULL,
    name character varying(150) NOT NULL,
    phone character varying(20) NOT NULL,
    "alternatePhone" character varying(20),
    email character varying(100),
    dob date NOT NULL,
    gender public."Gender" NOT NULL,
    "bloodGroup" public."BloodGroup",
    "aadhaarNumber" character varying(12),
    occupation character varying(100),
    "photoUrl" text,
    "maritalStatus" public."MaritalStatus",
    nationality character varying(100) DEFAULT 'Indian'::character varying,
    remarks text,
    "hospitalId" text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.patients OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    "amountPaid" numeric(12,2) NOT NULL,
    "paymentMode" public."PaymentMode" NOT NULL,
    "transactionReference" character varying(100),
    "transactionGroupId" character varying(50),
    "receivedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "receivedBy" text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id text NOT NULL,
    "userId" text NOT NULL,
    module character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    "isAllowed" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- Name: pharmacy_invoice_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pharmacy_invoice_items (
    id text NOT NULL,
    "pharmacyInvoiceId" text NOT NULL,
    "medicineId" text NOT NULL,
    "batchNumber" character varying(50) NOT NULL,
    "quantitySold" integer NOT NULL,
    "unitPrice" numeric(12,2) NOT NULL,
    "totalPrice" numeric(12,2) NOT NULL,
    "gstPercentage" numeric(5,2) DEFAULT 0.00 NOT NULL,
    "discountAmount" numeric(12,2) DEFAULT 0.00 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.pharmacy_invoice_items OWNER TO postgres;

--
-- Name: pharmacy_invoice_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pharmacy_invoice_payments (
    id text NOT NULL,
    "pharmacyInvoiceId" text NOT NULL,
    "paymentMode" public."PaymentMode" NOT NULL,
    amount numeric(12,2) NOT NULL
);


ALTER TABLE public.pharmacy_invoice_payments OWNER TO postgres;

--
-- Name: pharmacy_invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pharmacy_invoices (
    id text NOT NULL,
    "pharmacyInvoiceNumber" character varying(30) NOT NULL,
    "customerType" public."PharmacyCustomerType" NOT NULL,
    "patientId" text,
    "hospitalId" text NOT NULL,
    "customerName" character varying(150) NOT NULL,
    "customerPhone" character varying(20),
    "totalAmount" numeric(12,2) NOT NULL,
    "discountAmount" numeric(12,2) DEFAULT 0.00 NOT NULL,
    "payableAmount" numeric(12,2) NOT NULL,
    "paymentMode" public."PaymentMode" DEFAULT 'CASH'::public."PaymentMode" NOT NULL,
    "receivedBy" text NOT NULL,
    status public."InvoiceStatus" DEFAULT 'PAID'::public."InvoiceStatus" NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "cancelledBy" text,
    "cancellationReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.pharmacy_invoices OWNER TO postgres;

--
-- Name: pharmacy_purchase_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pharmacy_purchase_items (
    id text NOT NULL,
    "purchaseOrderId" text NOT NULL,
    "medicineId" text NOT NULL,
    "batchNumber" character varying(50) NOT NULL,
    "expiryDate" date,
    "quantityReceived" integer NOT NULL,
    "unitCost" numeric(12,2) NOT NULL,
    "purchaseRate" numeric(12,2) DEFAULT 0.00 NOT NULL,
    "sellingRate" numeric(12,2) DEFAULT 0.00 NOT NULL,
    "gstPercentage" numeric(5,2) DEFAULT 0.00 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.pharmacy_purchase_items OWNER TO postgres;

--
-- Name: pharmacy_purchase_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pharmacy_purchase_orders (
    id text NOT NULL,
    "invoiceNumber" character varying(50) NOT NULL,
    "supplierName" character varying(150) NOT NULL,
    "orderDate" date NOT NULL,
    "totalCost" numeric(12,2) NOT NULL,
    "receivedBy" text NOT NULL,
    remarks text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.pharmacy_purchase_orders OWNER TO postgres;

--
-- Name: pharmacy_return_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pharmacy_return_items (
    id text NOT NULL,
    "pharmacyReturnId" text NOT NULL,
    "medicineId" text NOT NULL,
    "batchNumber" character varying(50) NOT NULL,
    "quantityReturned" integer NOT NULL,
    "refundRate" numeric(12,2) NOT NULL,
    "totalAmount" numeric(12,2) NOT NULL
);


ALTER TABLE public.pharmacy_return_items OWNER TO postgres;

--
-- Name: pharmacy_returns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pharmacy_returns (
    id text NOT NULL,
    "pharmacyInvoiceId" text NOT NULL,
    "returnNumber" character varying(30) NOT NULL,
    "refundAmount" numeric(12,2) NOT NULL,
    reason text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.pharmacy_returns OWNER TO postgres;

--
-- Name: pharmacy_stock_adjustments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pharmacy_stock_adjustments (
    id text NOT NULL,
    "medicineId" text NOT NULL,
    "batchNumber" character varying(50) NOT NULL,
    "adjustmentType" public."PharmacyAdjustmentType" NOT NULL,
    "stockBefore" integer NOT NULL,
    quantity integer NOT NULL,
    "stockAfter" integer NOT NULL,
    reason text NOT NULL,
    "employeeId" text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdBy" uuid
);


ALTER TABLE public.pharmacy_stock_adjustments OWNER TO postgres;

--
-- Name: print_histories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.print_histories (
    id text NOT NULL,
    "documentType" character varying(50) NOT NULL,
    "documentId" character varying(50) NOT NULL,
    "printedById" text NOT NULL,
    "printedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "templateId" text,
    "templateVersion" integer DEFAULT 1 NOT NULL,
    "requestId" character varying(50),
    "printedFromModule" character varying(50) NOT NULL,
    "brandingSnapshot" jsonb NOT NULL
);


ALTER TABLE public.print_histories OWNER TO postgres;

--
-- Name: print_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.print_templates (
    id text NOT NULL,
    "templateKey" character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    "layoutJson" jsonb NOT NULL,
    "pageFormat" character varying(30) NOT NULL,
    "hospitalId" text NOT NULL,
    "documentType" character varying(50) NOT NULL,
    status public."PrintTemplateStatus" DEFAULT 'DRAFT'::public."PrintTemplateStatus" NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "isPublished" boolean DEFAULT false NOT NULL,
    category character varying(50) DEFAULT 'General'::character varying NOT NULL,
    orientation character varying(20) DEFAULT 'PORTRAIT'::character varying NOT NULL,
    margins character varying(30) DEFAULT '15mm'::character varying NOT NULL,
    copies integer DEFAULT 1 NOT NULL,
    language character varying(20) DEFAULT 'en'::character varying NOT NULL,
    "isSystemDefault" boolean DEFAULT false NOT NULL,
    "thumbnailUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.print_templates OWNER TO postgres;

--
-- Name: radiology_findings_revisions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.radiology_findings_revisions (
    id text NOT NULL,
    "scanOrderId" text NOT NULL,
    "revisionNumber" integer NOT NULL,
    findings text NOT NULL,
    remarks text,
    "technicianId" uuid,
    "verifiedById" uuid,
    "completedAt" timestamp(3) without time zone NOT NULL,
    "completedBy" text NOT NULL,
    "editedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "editedBy" uuid NOT NULL
);


ALTER TABLE public.radiology_findings_revisions OWNER TO postgres;

--
-- Name: radiology_scan_catalogs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.radiology_scan_catalogs (
    id text NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(150) NOT NULL,
    category character varying(50) NOT NULL,
    "standardRate" numeric(12,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.radiology_scan_catalogs OWNER TO postgres;

--
-- Name: radiology_scan_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.radiology_scan_orders (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "scanCatalogId" text NOT NULL,
    "orderedByDoctorId" text NOT NULL,
    "opdConsultationId" text,
    "ipdAdmissionId" text,
    "billableChargeId" text,
    status public."RadiologyStatus" DEFAULT 'SCHEDULED'::public."RadiologyStatus" NOT NULL,
    findings text,
    remarks text,
    "technicianId" uuid,
    "verifiedById" uuid,
    "cancelledAt" timestamp(3) without time zone,
    "cancelledBy" uuid,
    "cancellationReason" text,
    "completedAt" timestamp(3) without time zone,
    "completedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.radiology_scan_orders OWNER TO postgres;

--
-- Name: refunds; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refunds (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    "paymentId" text,
    "amountRefunded" numeric(12,2) NOT NULL,
    "refundReason" text NOT NULL,
    "refundedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "refundedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.refunds OWNER TO postgres;

--
-- Name: sequences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sequences (
    "sequenceName" character varying(100) NOT NULL,
    "currentValue" bigint DEFAULT 0 NOT NULL,
    prefix character varying(20) NOT NULL,
    "paddingLength" integer DEFAULT 5 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    description text,
    "lastGeneratedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.sequences OWNER TO postgres;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "ipAddress" character varying(45),
    "userAgent" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    id text NOT NULL,
    "settingKey" character varying(100) NOT NULL,
    "settingValue" text NOT NULL,
    "dataType" character varying(30) DEFAULT 'STRING'::character varying NOT NULL,
    category character varying(50) DEFAULT 'GENERAL'::character varying NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" uuid,
    "updatedBy" uuid,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "deletedBy" uuid
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- Name: wards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wards (
    id text NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(20) NOT NULL,
    "floorId" text NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.wards OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea
)
PARTITION BY RANGE (inserted_at);


ALTER TABLE realtime.messages OWNER TO supabase_realtime_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE realtime.schema_migrations OWNER TO supabase_admin;

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    action_filter text DEFAULT '*'::text,
    selected_columns text[],
    CONSTRAINT subscription_action_filter_check CHECK ((action_filter = ANY (ARRAY['*'::text, 'INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


ALTER TABLE realtime.subscription OWNER TO supabase_admin;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE storage.buckets_analytics OWNER TO supabase_storage_admin;

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.buckets_vectors OWNER TO supabase_storage_admin;

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb,
    metadata jsonb
);


ALTER TABLE storage.s3_multipart_uploads OWNER TO supabase_storage_admin;

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.s3_multipart_uploads_parts OWNER TO supabase_storage_admin;

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.vector_indexes OWNER TO supabase_storage_admin;

--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at, custom_claims_allowlist) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: audits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audits (id, "timestamp", "userId", "clientIp", action, resource, "entityId", "requestId", "previousState", "newState", reason, description) FROM stdin;
8be0c5d7-84f0-4c82-b01c-06445def20b4	2026-07-11 08:32:28.213	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	LOGIN	Employee	18e007d1-7d3c-41b6-9b4c-900c977bf474	\N	\N	\N	\N	Successful login for employee ayushmishraofficial142@gmail.com using Argon2Provider
dbe3739a-355b-4c6f-8f4d-b1c2c3eca72f	2026-07-11 08:44:46.141	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	PATIENT_REGISTERED_WITH_BYPASS	Patient	c79df73a-139f-4eef-87b5-02689074d42a	4b161bfa-a178-48f3-ba06-4e4403bd3497	null	{"name": "patient 1", "uhid": "BH11072600001", "phone": "1234567891", "duplicateBypassed": true}	\N	Registered patient patient 1 with UHID BH11072600001.
4f5b1146-7eb6-4766-8449-322f0e7e10b7	2026-07-11 08:46:06.427	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	EMPLOYEE_CREATE	Employee	3afd33f4-a236-483d-be4e-46320046a216	bf489358-1ce9-49a1-a4aa-e337492b1c03	null	{"id": "3afd33f4-a236-483d-be4e-46320046a216", "role": "EMPLOYEE", "email": "doc@gmail.com", "designation": "Doctor", "employeeCode": "EMP002"}	\N	Created new employee: doc@gmail.com (EMP002)
c27b61a9-ed99-4ca3-93de-47357b1889c1	2026-07-11 08:47:03.571	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	EMPLOYEE_CREATE	Employee	fad78794-e7a8-49ea-b461-2fea6eb9b2c6	b77d63c4-e7d0-4dfb-a547-f19a6dd56c63	null	{"id": "fad78794-e7a8-49ea-b461-2fea6eb9b2c6", "role": "EMPLOYEE", "email": "doctor@hos.com", "designation": "Doctor", "employeeCode": "EMP003"}	\N	Created new employee: doctor@hos.com (EMP003)
a7f1c16d-7038-451f-9bc6-62a492162d8d	2026-07-11 08:47:04.083	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	DOCTOR_CREATE	Doctor	fad78794-e7a8-49ea-b461-2fea6eb9b2c6	b77d63c4-e7d0-4dfb-a547-f19a6dd56c63	null	{"id": "fad78794-e7a8-49ea-b461-2fea6eb9b2c6", "createdAt": "2026-07-11T08:47:03.875Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": false, "updatedAt": "2026-07-11T08:47:03.875Z", "updatedBy": null, "roomNumber": "102", "dutySchedule": null, "qualification": "MBBS", "specialization": "Medicine", "consultationFee": "300", "registrationNumber": "DOC26001"}	\N	Created doctor profile for staff doctor@hos.com ()
3e044a03-8704-4acb-ae52-9f22dfeea5cd	2026-07-11 08:47:23.752	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	DEPARTMENT_UPDATE	Department	9fd6744e-743c-4c33-b0a2-7e9547125bb0	a2181b44-8951-4491-8157-f42c396e149c	{"id": "9fd6744e-743c-4c33-b0a2-7e9547125bb0", "code": "ENT", "name": "ENT", "createdAt": "2026-07-11T08:30:13.507Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": false, "updatedAt": "2026-07-11T08:30:13.507Z", "updatedBy": null, "description": "Ear, nose, and throat treatment"}	{"id": "9fd6744e-743c-4c33-b0a2-7e9547125bb0", "code": "ENT", "name": "ENT", "createdAt": "2026-07-11T08:30:13.507Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": true, "updatedAt": "2026-07-11T08:47:23.537Z", "updatedBy": null, "description": "Ear, nose, and throat treatment"}	\N	Updated clinical department ENT (ENT). Status: Disabled
12832aee-3d66-42f8-bf3d-df0ad90b3ae5	2026-07-11 08:47:23.843	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	DEPARTMENT_UPDATE	Department	3c03bf6f-c981-4aa4-a54d-c8191302fec9	9f6606eb-a2ba-4619-870f-737c5f0addf6	{"id": "3c03bf6f-c981-4aa4-a54d-c8191302fec9", "code": "DENT", "name": "Dental", "createdAt": "2026-07-11T08:30:14.039Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": false, "updatedAt": "2026-07-11T08:30:14.039Z", "updatedBy": null, "description": "Oral care and dental treatment"}	{"id": "3c03bf6f-c981-4aa4-a54d-c8191302fec9", "code": "DENT", "name": "Dental", "createdAt": "2026-07-11T08:30:14.039Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": true, "updatedAt": "2026-07-11T08:47:23.647Z", "updatedBy": null, "description": "Oral care and dental treatment"}	\N	Updated clinical department Dental (DENT). Status: Disabled
8549e20c-32fc-48ed-b237-14f5fca2148e	2026-07-11 08:47:23.844	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	DEPARTMENT_UPDATE	Department	ea4befe6-d828-45ac-97b4-00953ef39145	7260dc4b-1b97-4007-8fd3-262167daabba	{"id": "ea4befe6-d828-45ac-97b4-00953ef39145", "code": "OBGYN", "name": "Obstetrics & Gynecology", "createdAt": "2026-07-11T08:30:13.412Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": false, "updatedAt": "2026-07-11T08:30:13.412Z", "updatedBy": null, "description": "Maternal, obstetric, and gynecological care"}	{"id": "ea4befe6-d828-45ac-97b4-00953ef39145", "code": "OBGYN", "name": "Obstetrics & Gynecology", "createdAt": "2026-07-11T08:30:13.412Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": true, "updatedAt": "2026-07-11T08:47:23.646Z", "updatedBy": null, "description": "Maternal, obstetric, and gynecological care"}	\N	Updated clinical department Obstetrics & Gynecology (OBGYN). Status: Disabled
6deab231-4557-4b53-a193-8ca4318ba54e	2026-07-11 08:47:25.354	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	DEPARTMENT_UPDATE	Department	defc0dfc-b38a-4893-ac79-a83ca19b39d1	a660bfa0-a15f-4144-9cb4-ce52a28e4606	{"id": "defc0dfc-b38a-4893-ac79-a83ca19b39d1", "code": "ORTHO", "name": "Orthopedic", "createdAt": "2026-07-11T08:30:13.318Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": false, "updatedAt": "2026-07-11T08:30:13.318Z", "updatedBy": null, "description": "Bone, joint, and orthopedic care"}	{"id": "defc0dfc-b38a-4893-ac79-a83ca19b39d1", "code": "ORTHO", "name": "Orthopedic", "createdAt": "2026-07-11T08:30:13.318Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": true, "updatedAt": "2026-07-11T08:47:25.261Z", "updatedBy": null, "description": "Bone, joint, and orthopedic care"}	\N	Updated clinical department Orthopedic (ORTHO). Status: Disabled
2ef4a43b-48be-47c9-9370-6a3d28dffb52	2026-07-11 08:47:26.601	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	DEPARTMENT_UPDATE	Department	07ecf8fa-4435-4e23-94b8-0cec1c77bb09	f52a3d4d-88e1-48f6-bd68-f8fdd9c3fad1	{"id": "07ecf8fa-4435-4e23-94b8-0cec1c77bb09", "code": "EMER", "name": "Emergency", "createdAt": "2026-07-11T08:30:13.951Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": false, "updatedAt": "2026-07-11T08:30:13.951Z", "updatedBy": null, "description": "24/7 urgent and emergency care"}	{"id": "07ecf8fa-4435-4e23-94b8-0cec1c77bb09", "code": "EMER", "name": "Emergency", "createdAt": "2026-07-11T08:30:13.951Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": true, "updatedAt": "2026-07-11T08:47:26.555Z", "updatedBy": null, "description": "24/7 urgent and emergency care"}	\N	Updated clinical department Emergency (EMER). Status: Disabled
c2b53f1a-cd4d-4686-b766-1366f8b6eed4	2026-07-11 08:47:27.985	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	DEPARTMENT_UPDATE	Department	5b9edfbf-2c23-4592-b7c3-df91fd81bc9c	82e8ba3b-6dae-43dc-b871-cc10bbafe0f3	{"id": "5b9edfbf-2c23-4592-b7c3-df91fd81bc9c", "code": "PED", "name": "Pediatrics", "createdAt": "2026-07-11T08:30:13.228Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": false, "updatedAt": "2026-07-11T08:30:13.228Z", "updatedBy": null, "description": "Children wellness and pediatric care"}	{"id": "5b9edfbf-2c23-4592-b7c3-df91fd81bc9c", "code": "PED", "name": "Pediatrics", "createdAt": "2026-07-11T08:30:13.228Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": true, "updatedAt": "2026-07-11T08:47:27.934Z", "updatedBy": null, "description": "Children wellness and pediatric care"}	\N	Updated clinical department Pediatrics (PED). Status: Disabled
79c0f8d0-5a10-4c5e-8237-610bd60e096f	2026-07-11 08:47:30.091	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	DEPARTMENT_UPDATE	Department	d84c128c-e788-4eaa-965a-5bad0e31f36f	ed30fc0b-c48d-4d40-bb91-b172a28061d7	{"id": "d84c128c-e788-4eaa-965a-5bad0e31f36f", "code": "PSYCH", "name": "Psychiatry", "createdAt": "2026-07-11T08:30:13.856Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": false, "updatedAt": "2026-07-11T08:30:13.856Z", "updatedBy": null, "description": "Mental health and psychiatric consultations"}	{"id": "d84c128c-e788-4eaa-965a-5bad0e31f36f", "code": "PSYCH", "name": "Psychiatry", "createdAt": "2026-07-11T08:30:13.856Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": true, "updatedAt": "2026-07-11T08:47:29.988Z", "updatedBy": null, "description": "Mental health and psychiatric consultations"}	\N	Updated clinical department Psychiatry (PSYCH). Status: Disabled
a91f1dd9-1b32-48c4-8f86-bcaac28f5b80	2026-07-11 08:47:32.855	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	DEPARTMENT_UPDATE	Department	091ef169-88cc-459c-afff-6f7db2c6cc5d	94293a7d-10c1-433a-8bb0-e52ceab2666d	{"id": "091ef169-88cc-459c-afff-6f7db2c6cc5d", "code": "DERM", "name": "Dermatology", "createdAt": "2026-07-11T08:30:13.732Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": false, "updatedAt": "2026-07-11T08:30:13.732Z", "updatedBy": null, "description": "Skin wellness and dermatological care"}	{"id": "091ef169-88cc-459c-afff-6f7db2c6cc5d", "code": "DERM", "name": "Dermatology", "createdAt": "2026-07-11T08:30:13.732Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": true, "updatedAt": "2026-07-11T08:47:32.758Z", "updatedBy": null, "description": "Skin wellness and dermatological care"}	\N	Updated clinical department Dermatology (DERM). Status: Disabled
a762190f-fbfb-4fb5-adaf-5eca2928f9cb	2026-07-11 08:47:34.596	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	DEPARTMENT_UPDATE	Department	f7f0ff24-6c35-423d-abbd-e7df8bfeeded	b88b117d-6f0e-4d97-8e25-065472ef1ceb	{"id": "f7f0ff24-6c35-423d-abbd-e7df8bfeeded", "code": "OPHTH", "name": "Ophthalmology", "createdAt": "2026-07-11T08:30:13.598Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": false, "updatedAt": "2026-07-11T08:30:13.598Z", "updatedBy": null, "description": "Eye health and ophthalmic care"}	{"id": "f7f0ff24-6c35-423d-abbd-e7df8bfeeded", "code": "OPHTH", "name": "Ophthalmology", "createdAt": "2026-07-11T08:30:13.598Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": true, "updatedAt": "2026-07-11T08:47:34.493Z", "updatedBy": null, "description": "Eye health and ophthalmic care"}	\N	Updated clinical department Ophthalmology (OPHTH). Status: Disabled
56e03eba-c05e-459e-beae-5e80e93c24e4	2026-07-11 08:48:11.873	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	OPD_REGISTERED	OPDConsultation	f3d03a1f-2b2e-44b8-a20d-57d6870ead97	d6112101-cce3-4fdc-8e24-8f60970979b0	null	{"opdId": "OPD260001", "appliedFee": 300, "doctorName": "Doctor", "patientName": "patient 1", "tokenNumber": 1}	\N	Registered patient patient 1 for OPD with ID OPD260001 (Token #1).
abe7e3a6-7edb-48e9-8ddd-aee8355ea5f7	2026-07-11 08:47:31.627	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	DEPARTMENT_UPDATE	Department	705a7b38-3fd9-491c-aad8-89c19d68d81b	53cd8554-ec5a-4f62-841e-6a39c1e89123	{"id": "705a7b38-3fd9-491c-aad8-89c19d68d81b", "code": "SURG", "name": "Surgery", "createdAt": "2026-07-11T08:30:13.129Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": false, "updatedAt": "2026-07-11T08:30:13.129Z", "updatedBy": null, "description": "General surgical procedures and consultations"}	{"id": "705a7b38-3fd9-491c-aad8-89c19d68d81b", "code": "SURG", "name": "Surgery", "createdAt": "2026-07-11T08:30:13.129Z", "createdBy": null, "deletedAt": null, "deletedBy": null, "isDeleted": true, "updatedAt": "2026-07-11T08:47:31.525Z", "updatedBy": null, "description": "General surgical procedures and consultations"}	\N	Updated clinical department Surgery (SURG). Status: Disabled
c319c5cc-9e43-475b-aa8c-64d171cab3fd	2026-07-11 09:33:23.166	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	PATIENT_UPDATED	Patient	c79df73a-139f-4eef-87b5-02689074d42a	3361b5aa-8fa1-43dd-8b5d-7cba875e5109	{"email": null, "remarks": null, "occupation": null, "alternatePhone": null}	{"email": "", "remarks": "", "occupation": "", "alternatePhone": ""}	\N	Updated demographic parameters for patient patient 1 (UHID BH11072600001).
c17038f4-e90d-4186-94bf-bbdd7ab589f5	2026-07-11 09:45:41.314	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	BACKUP_CREATED	System	\N	22e0485b-fe58-45bc-b13e-983a5ee5ac97	null	null	\N	Created new FULL backup archive file 'backup_FULL_1783763099493_63dc21094234e72473f1b6d88c7426e66425d1bb7419d93544ebd5a3e4194032.zip' with checksum '63dc21094234e72473f1b6d88c7426e66425d1bb7419d93544ebd5a3e4194032'
68ca2c3b-a88b-4095-be5a-b853b329c057	2026-07-11 09:51:12.1	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	BACKUP_CREATED	System	\N	963738e2-ed38-483a-b333-d53c62edc664	null	null	\N	Created new FULL backup archive file 'backup_FULL_1783763448897_e2653050cfa6b7ed0357396a867e5bd992837e89a04185bae1c83e09fdf94a37.zip' with checksum 'e2653050cfa6b7ed0357396a867e5bd992837e89a04185bae1c83e09fdf94a37'
0f985728-4bbb-46b9-a8ea-fb5e6af3c25c	2026-07-11 09:56:44.408	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	BACKUP_CREATED	System	\N	90c3b9bc-68bb-41b3-b5b4-7c42c1ddcb8e	null	null	\N	Created new FULL backup archive file 'backup_FULL_1783763774539_c3eaa676817a9d6b57169e2dce331f9cf8ca31eaaf3dbf8b74e30a812633d7b5.zip' with checksum 'c3eaa676817a9d6b57169e2dce331f9cf8ca31eaaf3dbf8b74e30a812633d7b5'
2c5a80d0-f4a9-4b96-ad1a-9a84b1d9487f	2026-07-11 10:09:06.793	18e007d1-7d3c-41b6-9b4c-900c977bf474	::ffff:127.0.0.1	BACKUP_CREATED	System	\N	6629e539-67d0-43ea-8e62-ebf57182270b	null	null	\N	Created new FULL backup archive file 'backup_FULL_1783764522755_9e8e2ee9246e189a8957d483d5f7981f4ad545a0544040ebd9e12d5f8f7b1425.zip' with checksum '9e8e2ee9246e189a8957d483d5f7981f4ad545a0544040ebd9e12d5f8f7b1425'
\.


--
-- Data for Name: bed_rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bed_rooms (id, "roomNumber", "roomType", "chargePerDay", "wardId", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: bed_transfer_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bed_transfer_history (id, "ipdAdmissionId", "previousBedId", "newBedId", "transferDate", "transferReason", "transferredBy", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: beds; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.beds (id, "roomId", "bedNumber", status, "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: billable_charges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.billable_charges (id, "patientId", "chargeCatalogId", "sourceModule", "sourceEntityId", quantity, rate, "totalAmount", "billingStatus", version, "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
5ec3dccb-bade-46ef-977a-ebcc08589733	c79df73a-139f-4eef-87b5-02689074d42a	3cab3513-4223-41b3-8768-dbd784ee663b	OPD	f3d03a1f-2b2e-44b8-a20d-57d6870ead97	1	300.00	300.00	INVOICED	1	2026-07-11 08:48:09.825	2026-07-11 08:48:11.258	18e007d1-7d3c-41b6-9b4c-900c977bf474	\N	f	\N	\N
\.


--
-- Data for Name: birth_registrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.birth_registrations (id, "babyName", dob, gender, "weightKg", "motherPatientId", "ipdAdmissionId", "hospitalId", "deliveryType", "attendingDoctorId", "certificateNumber", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: buildings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.buildings (id, name, code, "isDeleted", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: charge_catalogs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.charge_catalogs (id, code, name, category, rate, "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy", "otType") FROM stdin;
3cab3513-4223-41b3-8768-dbd784ee663b	OPD_CONSULTATION	Outpatient Consultation Fee	OPD	300.00	2026-07-11 08:48:09.62	2026-07-11 08:48:09.62	\N	\N	f	\N	\N	\N
\.


--
-- Data for Name: death_registrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.death_registrations (id, "patientId", "ipdAdmissionId", "hospitalId", "deceasedName", "deceasedAge", "deceasedGender", "dateOfDeath", "causeOfDeath", "locationType", "attendingDoctorId", "informantDetails", "certificateNumber", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.departments (id, name, code, description, "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
9437180e-17b4-49c9-86c7-1f12cb5dce93	Medicine	MED	General medicine and internal consultations	2026-07-11 08:30:12.989	2026-07-11 08:30:12.989	\N	\N	f	\N	\N
9fd6744e-743c-4c33-b0a2-7e9547125bb0	ENT	ENT	Ear, nose, and throat treatment	2026-07-11 08:30:13.507	2026-07-11 08:47:23.537	\N	\N	t	\N	\N
3c03bf6f-c981-4aa4-a54d-c8191302fec9	Dental	DENT	Oral care and dental treatment	2026-07-11 08:30:14.039	2026-07-11 08:47:23.647	\N	\N	t	\N	\N
ea4befe6-d828-45ac-97b4-00953ef39145	Obstetrics & Gynecology	OBGYN	Maternal, obstetric, and gynecological care	2026-07-11 08:30:13.412	2026-07-11 08:47:23.646	\N	\N	t	\N	\N
defc0dfc-b38a-4893-ac79-a83ca19b39d1	Orthopedic	ORTHO	Bone, joint, and orthopedic care	2026-07-11 08:30:13.318	2026-07-11 08:47:25.261	\N	\N	t	\N	\N
07ecf8fa-4435-4e23-94b8-0cec1c77bb09	Emergency	EMER	24/7 urgent and emergency care	2026-07-11 08:30:13.951	2026-07-11 08:47:26.555	\N	\N	t	\N	\N
5b9edfbf-2c23-4592-b7c3-df91fd81bc9c	Pediatrics	PED	Children wellness and pediatric care	2026-07-11 08:30:13.228	2026-07-11 08:47:27.934	\N	\N	t	\N	\N
d84c128c-e788-4eaa-965a-5bad0e31f36f	Psychiatry	PSYCH	Mental health and psychiatric consultations	2026-07-11 08:30:13.856	2026-07-11 08:47:29.988	\N	\N	t	\N	\N
705a7b38-3fd9-491c-aad8-89c19d68d81b	Surgery	SURG	General surgical procedures and consultations	2026-07-11 08:30:13.129	2026-07-11 08:47:31.525	\N	\N	t	\N	\N
091ef169-88cc-459c-afff-6f7db2c6cc5d	Dermatology	DERM	Skin wellness and dermatological care	2026-07-11 08:30:13.732	2026-07-11 08:47:32.758	\N	\N	t	\N	\N
f7f0ff24-6c35-423d-abbd-e7df8bfeeded	Ophthalmology	OPHTH	Eye health and ophthalmic care	2026-07-11 08:30:13.598	2026-07-11 08:47:34.493	\N	\N	t	\N	\N
\.


--
-- Data for Name: discharge_summary_revisions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.discharge_summary_revisions (id, "ipdAdmissionId", "revisionNumber", summary, "editedAt", "editedBy") FROM stdin;
\.


--
-- Data for Name: doctor_assignment_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctor_assignment_history (id, "ipdAdmissionId", "previousDoctorId", "assignedDoctorId", "effectiveFrom", "effectiveTo", "changedBy", reason, "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: doctors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctors (id, "registrationNumber", qualification, specialization, "consultationFee", "roomNumber", "dutySchedule", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
fad78794-e7a8-49ea-b461-2fea6eb9b2c6	DOC26001	MBBS	Medicine	300.00	102	null	2026-07-11 08:47:03.875	2026-07-11 08:47:03.875	\N	\N	f	\N	\N
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (id, name, "employeeCode", email, "passwordHash", role, designation, "departmentId", "hospitalId", "mobileNumber", "joiningDate", "isActive", "failedLoginCount", "lockedUntil", "passwordChangedAt", "lastLoginAt", "lastLoginIp", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
18e007d1-7d3c-41b6-9b4c-900c977bf474	System Administrator	EMP001	ayushmishraofficial142@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$Z8Fxc8dKet9EaivV4ZUEDw$TfL9SApOs6blOReWaNKvtH/Vn5xQwM61ZtB0UK1dbOs	SUPER_ADMIN	System Administrator	\N	5ed5f2a0-272c-494a-836a-ad6b5d7f3d9a	9999999999	2026-07-11 08:30:08.234	t	0	\N	2026-07-11 08:30:08.234	2026-07-11 08:32:26.688	::ffff:127.0.0.1	2026-07-11 08:30:08.239	2026-07-11 08:32:27.394	\N	\N	f	\N	\N
3afd33f4-a236-483d-be4e-46320046a216	Doctor a	EMP002	doc@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$k9JYbiyFnS+8GwyyXO3N5A$EbEW/X4UKC0FWuQq+P/dPT3qGKTzwSws14BE1wqtut0	EMPLOYEE	Doctor	9437180e-17b4-49c9-86c7-1f12cb5dce93	5ed5f2a0-272c-494a-836a-ad6b5d7f3d9a	1111111111	2026-07-11 00:00:00	t	0	\N	2026-07-11 08:46:06.183	\N	\N	2026-07-11 08:46:06.183	2026-07-11 08:46:06.183	\N	\N	f	\N	\N
fad78794-e7a8-49ea-b461-2fea6eb9b2c6	Dr. A	EMP003	doctor@hos.com	$argon2id$v=19$m=65536,t=3,p=4$Q+urNza4KERd52QODTPISA$5lwwxY+59SlXL8GbCi6f34SV8pTEcSZX/2OcvMMu5bk	EMPLOYEE	Doctor	9437180e-17b4-49c9-86c7-1f12cb5dce93	5ed5f2a0-272c-494a-836a-ad6b5d7f3d9a	1111111111	2026-07-11 00:00:00	t	0	\N	2026-07-11 08:47:03.364	\N	\N	2026-07-11 08:47:03.364	2026-07-11 08:47:03.364	\N	\N	f	\N	\N
\.


--
-- Data for Name: floors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.floors (id, name, "buildingId", "isDeleted", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: hospitals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hospitals (id, name, code, phone, email, address, "gstNumber", "registrationNumber", website, "logoUrl", "footerText", "stateInsuranceLicense", "currentVersion", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
5ed5f2a0-272c-494a-836a-ad6b5d7f3d9a	Balaji Hospital	BH	0123456789	info@balajihospital.com	Circular Road, Balaji Complex, NCR	\N	\N	\N	\N	\N	\N	2.0.0	2026-07-11 08:30:07.988	2026-07-11 08:30:07.988	\N	\N	f	\N	\N
\.


--
-- Data for Name: invoice_charge_mappings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_charge_mappings (id, "invoiceId", "billableChargeId", "createdAt", "updatedAt", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
3b7b858f-029a-4e5f-ae8b-39d888510b71	cdebb3eb-902c-4bb6-8b12-bb3aec3d5c45	5ec3dccb-bade-46ef-977a-ebcc08589733	2026-07-11 08:48:11.057	2026-07-11 08:48:11.057	f	\N	\N
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, "invoiceNumber", "patientId", "hospitalId", "totalAmount", "discountAmount", "discountPercentage", "discountReason", "discountApprovedBy", "payableAmount", "paidAmount", "balanceAmount", "paymentStatus", version, "cancelledAt", "cancelledBy", "cancellationReason", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
cdebb3eb-902c-4bb6-8b12-bb3aec3d5c45	INV26000001	c79df73a-139f-4eef-87b5-02689074d42a	5ed5f2a0-272c-494a-836a-ad6b5d7f3d9a	300.00	0.00	\N	\N	\N	300.00	300.00	0.00	PAID	1	\N	\N	\N	2026-07-11 08:48:10.849	2026-07-11 08:48:10.849	18e007d1-7d3c-41b6-9b4c-900c977bf474	\N	f	\N	\N
\.


--
-- Data for Name: ipd_admissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ipd_admissions (id, "ipdId", "patientId", "bedId", "primaryDoctorId", "departmentId", "hospitalId", "admissionDate", "dischargeDate", "dischargeSummary", "dischargeBy", "isDeceased", version, "codeStatus", "isolationStatus", "referredByDoctorId", "isMLC", "mlcNumber", "admissionSource", "admissionCategory", "initialDepositRequired", "admissionReason", status, "dischargeType", "finalDiagnosis", "treatmentSummary", "conditionAtDischarge", "followUpInstructions", "cancelledAt", "cancelledBy", "cancellationReason", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: ipd_attendants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ipd_attendants (id, "ipdAdmissionId", name, relationship, mobile, "isActive", "createdAt", "updatedAt", "isDeleted") FROM stdin;
\.


--
-- Data for Name: ipd_clinical_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ipd_clinical_attachments (id, "ipdAdmissionId", "documentType", "fileUrl", description, "recordedBy", "createdAt", "isDeleted") FROM stdin;
\.


--
-- Data for Name: ipd_consultations_clinical; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ipd_consultations_clinical (id, "ipdAdmissionId", "targetDepartmentId", "targetDoctorId", reason, urgency, status, "completionNotes", "recordedBy", "createdAt", "updatedAt", "isDeleted") FROM stdin;
\.


--
-- Data for Name: ipd_doctor_rounds; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ipd_doctor_rounds (id, "ipdAdmissionId", "doctorId", condition, findings, recommendations, "recordedBy", "createdAt", "isDeleted") FROM stdin;
\.


--
-- Data for Name: ipd_handovers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ipd_handovers (id, "ipdAdmissionId", "recipientUserId", "conditionSummary", checklist, remarks, "recordedBy", "createdAt", "isDeleted") FROM stdin;
\.


--
-- Data for Name: ipd_intake_output; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ipd_intake_output (id, "ipdAdmissionId", "intakeMl", "intakeType", "outputMl", "outputType", remarks, "recordedBy", "createdAt", "isDeleted") FROM stdin;
\.


--
-- Data for Name: ipd_nursing_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ipd_nursing_tasks (id, "ipdAdmissionId", description, "scheduledTime", status, "recordedBy", "createdAt", "updatedAt", "isDeleted") FROM stdin;
\.


--
-- Data for Name: ipd_progress_notes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ipd_progress_notes (id, "ipdAdmissionId", "noteType", content, version, "isAmended", "amendmentReason", "parentNoteId", "recordedBy", "createdAt", "updatedAt", "isDeleted") FROM stdin;
\.


--
-- Data for Name: ipd_timeline_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ipd_timeline_events (id, "ipdAdmissionId", "eventType", description, "recordedBy", "createdAt") FROM stdin;
\.


--
-- Data for Name: ipd_treatment_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ipd_treatment_orders (id, "ipdAdmissionId", "orderType", priority, description, status, "isVerified", "verifiedBy", "verifiedAt", "recordedBy", "createdAt", "updatedAt", "isDeleted") FROM stdin;
\.


--
-- Data for Name: ipd_vitals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ipd_vitals (id, "ipdAdmissionId", temperature, pulse, "systolicBP", "diastolicBP", spo2, "respiratoryRate", weight, height, "bloodSugar", "recordedBy", "createdAt", "isDeleted") FROM stdin;
\.


--
-- Data for Name: lab_result_revisions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lab_result_revisions (id, "testOrderId", "revisionNumber", results, remarks, "technicianId", "verifiedById", "completedAt", "completedBy", "editedAt", "editedBy") FROM stdin;
\.


--
-- Data for Name: lab_test_catalogs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lab_test_catalogs (id, code, name, category, "standardRate", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: lab_test_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lab_test_orders (id, "patientId", "testCatalogId", "orderedByDoctorId", "opdConsultationId", "ipdAdmissionId", "billableChargeId", "hospitalId", status, "sampleCollectedAt", "sampleCollectedBy", "cancelledAt", "cancelledBy", "cancellationReason", "technicianId", "verifiedById", remarks, "completedAt", "completedBy", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: lab_test_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lab_test_results (id, "testOrderId", "parameterName", "parameterValue", "referenceRange", unit, status, "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: medicine_stocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.medicine_stocks (id, "medicineId", "batchNumber", "expiryDate", "currentQuantity", "purchaseRate", "sellingRate", "gstPercentage", version, "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: medicines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.medicines (id, code, name, "genericName", category, form, "standardSellingPrice", brand, unit, "hsnCode", "gstPercentage", "purchasePrice", "sellingPrice", "minimumStock", "isActive", "isExpirable", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: opd_consultations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.opd_consultations (id, "opdId", "patientId", "doctorId", "departmentId", "hospitalId", "consultationDate", "depositAmount", "originalFee", "appliedFee", "overrideReason", "tokenNumber", version, symptoms, "cancelledAt", "cancelledBy", "cancellationReason", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
f3d03a1f-2b2e-44b8-a20d-57d6870ead97	OPD260001	c79df73a-139f-4eef-87b5-02689074d42a	fad78794-e7a8-49ea-b461-2fea6eb9b2c6	9437180e-17b4-49c9-86c7-1f12cb5dce93	5ed5f2a0-272c-494a-836a-ad6b5d7f3d9a	2026-07-11 08:48:09.215	300.00	300.00	300.00	\N	1	1	Fever	\N	\N	\N	2026-07-11 08:48:09.218	2026-07-11 08:48:09.218	18e007d1-7d3c-41b6-9b4c-900c977bf474	\N	f	\N	\N
\.


--
-- Data for Name: operation_theater_revisions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.operation_theater_revisions (id, "operationTheaterId", "revisionNumber", "operationName", diagnosis, "primarySurgeonId", "assistantSurgeonId", "departmentId", remarks, "editedAt", "editedBy") FROM stdin;
\.


--
-- Data for Name: operation_theaters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.operation_theaters (id, "otId", "ipdAdmissionId", "opdConsultationId", "patientId", "hospitalId", "departmentId", "operationType", "operationName", diagnosis, "scheduledDate", remarks, "completedAt", "completedBy", "cancelledAt", "cancelledBy", "cancellationReason", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy", "primarySurgeonId", "assistantSurgeonId", "procedureCatalogId") FROM stdin;
\.


--
-- Data for Name: patient_addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient_addresses (id, "patientId", "addressLine", city, state, pincode, "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
8768ed89-5061-4ad7-8329-b18f9fe20e8b	c79df73a-139f-4eef-87b5-02689074d42a	Bhatni Deoria	Bhatni deoria	N/A	000000	2026-07-11 08:44:44.717	2026-07-11 09:33:22.685	18e007d1-7d3c-41b6-9b4c-900c977bf474	18e007d1-7d3c-41b6-9b4c-900c977bf474	f	\N	\N
\.


--
-- Data for Name: patient_deposit_allocations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient_deposit_allocations (id, "depositId", "invoiceId", "amountAllocated", "transactionDate", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: patient_deposits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient_deposits (id, "patientId", "hospitalId", "opdConsultationId", amount, "collectedBy", "transactionDate", "isRefunded", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
7f116253-1a80-4d7b-bf1b-892227e1c9fd	c79df73a-139f-4eef-87b5-02689074d42a	5ed5f2a0-272c-494a-836a-ad6b5d7f3d9a	f3d03a1f-2b2e-44b8-a20d-57d6870ead97	300.00	18e007d1-7d3c-41b6-9b4c-900c977bf474	2026-07-11 08:48:10.133	f	2026-07-11 08:48:10.133	2026-07-11 08:48:10.133	18e007d1-7d3c-41b6-9b4c-900c977bf474	\N	f	\N	\N
\.


--
-- Data for Name: patient_emergency_contacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient_emergency_contacts (id, "patientId", name, phone, relation, "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
cccf9c7c-8437-482c-96b9-24dc3f5b8492	c79df73a-139f-4eef-87b5-02689074d42a	N/A	0000000000	N/A	2026-07-11 08:44:45.014	2026-07-11 09:33:22.816	18e007d1-7d3c-41b6-9b4c-900c977bf474	18e007d1-7d3c-41b6-9b4c-900c977bf474	f	\N	\N
\.


--
-- Data for Name: patient_referrals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient_referrals (id, "patientId", "referralType", "referralName", "referralNotes", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
ebf260b6-7ea7-4542-aaab-163795dcbce9	c79df73a-139f-4eef-87b5-02689074d42a	SELF	Self	\N	2026-07-11 08:44:45.323	2026-07-11 09:33:22.961	18e007d1-7d3c-41b6-9b4c-900c977bf474	18e007d1-7d3c-41b6-9b4c-900c977bf474	f	\N	\N
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patients (id, uhid, name, phone, "alternatePhone", email, dob, gender, "bloodGroup", "aadhaarNumber", occupation, "photoUrl", "maritalStatus", nationality, remarks, "hospitalId", version, "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
c79df73a-139f-4eef-87b5-02689074d42a	BH11072600001	patient 1	1234567891	\N	\N	2005-01-01	MALE	B_POSITIVE	\N	\N	\N	\N	Indian	\N	5ed5f2a0-272c-494a-836a-ad6b5d7f3d9a	2	2026-07-11 08:44:44.206	2026-07-11 09:33:22.326	18e007d1-7d3c-41b6-9b4c-900c977bf474	18e007d1-7d3c-41b6-9b4c-900c977bf474	f	\N	\N
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, "invoiceId", "amountPaid", "paymentMode", "transactionReference", "transactionGroupId", "receivedAt", "receivedBy", version, "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
6c62a3a3-c922-44fc-9c35-4b368edc0aef	cdebb3eb-902c-4bb6-8b12-bb3aec3d5c45	300.00	CASH	\N	PAY-OPD-OPD260001	2026-07-11 08:48:11.463	18e007d1-7d3c-41b6-9b4c-900c977bf474	1	2026-07-11 08:48:11.463	2026-07-11 08:48:11.463	18e007d1-7d3c-41b6-9b4c-900c977bf474	\N	f	\N	\N
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, "userId", module, action, "isAllowed", "createdAt", "updatedAt", "createdBy", "updatedBy") FROM stdin;
6014b1cd-00cb-4308-99e2-524950743e60	18e007d1-7d3c-41b6-9b4c-900c977bf474	Patient	View	t	2026-07-11 08:30:08.432	2026-07-11 08:30:08.432	\N	\N
dbc1c135-362a-41fe-830a-7374467e1ca4	18e007d1-7d3c-41b6-9b4c-900c977bf474	Patient	Create	t	2026-07-11 08:30:08.571	2026-07-11 08:30:08.571	\N	\N
6d4595d3-686c-4ff9-b52d-0e1e7be3871c	18e007d1-7d3c-41b6-9b4c-900c977bf474	Patient	Edit	t	2026-07-11 08:30:08.667	2026-07-11 08:30:08.667	\N	\N
38007caa-12e8-47eb-acf4-12f9f96aaab5	18e007d1-7d3c-41b6-9b4c-900c977bf474	Patient	Delete	t	2026-07-11 08:30:08.758	2026-07-11 08:30:08.758	\N	\N
6d368994-a090-4832-8856-0601029af6d7	18e007d1-7d3c-41b6-9b4c-900c977bf474	Patient	Print	t	2026-07-11 08:30:08.848	2026-07-11 08:30:08.848	\N	\N
fdf6c84d-0228-4973-a66c-d8ac87b525a0	18e007d1-7d3c-41b6-9b4c-900c977bf474	Billing	View	t	2026-07-11 08:30:08.94	2026-07-11 08:30:08.94	\N	\N
9be86d1f-dbb3-4907-88a3-c3b06b51bf2c	18e007d1-7d3c-41b6-9b4c-900c977bf474	Billing	ReceivePayment	t	2026-07-11 08:30:09.032	2026-07-11 08:30:09.032	\N	\N
e299c2ea-71e9-4c87-bfea-5d9802af6163	18e007d1-7d3c-41b6-9b4c-900c977bf474	Billing	Refund	t	2026-07-11 08:30:09.122	2026-07-11 08:30:09.122	\N	\N
5b9bff84-7f65-4ccf-afbe-0a08b9061d36	18e007d1-7d3c-41b6-9b4c-900c977bf474	Billing	Cancel	t	2026-07-11 08:30:09.214	2026-07-11 08:30:09.214	\N	\N
537c4434-83f1-4d75-b659-2d5af22bfa95	18e007d1-7d3c-41b6-9b4c-900c977bf474	Laboratory	View	t	2026-07-11 08:30:09.312	2026-07-11 08:30:09.312	\N	\N
44d7145f-3295-48b9-bee5-fda1e55f6bf9	18e007d1-7d3c-41b6-9b4c-900c977bf474	Laboratory	Create	t	2026-07-11 08:30:09.402	2026-07-11 08:30:09.402	\N	\N
d3c5db41-7553-49cb-92a0-79b0e5ecaff7	18e007d1-7d3c-41b6-9b4c-900c977bf474	Laboratory	Complete	t	2026-07-11 08:30:09.496	2026-07-11 08:30:09.496	\N	\N
3c2890ae-f67f-4bb5-86fe-bb0b4f4a9bdc	18e007d1-7d3c-41b6-9b4c-900c977bf474	Laboratory	Print	t	2026-07-11 08:30:09.586	2026-07-11 08:30:09.586	\N	\N
eca6e313-ffd4-40e6-b229-627fc79d8416	18e007d1-7d3c-41b6-9b4c-900c977bf474	OT	View	t	2026-07-11 08:30:09.937	2026-07-11 08:30:09.937	\N	\N
af49ca04-cb0c-472a-a75f-efe6cbc25dd6	18e007d1-7d3c-41b6-9b4c-900c977bf474	OT	Create	t	2026-07-11 08:30:10.041	2026-07-11 08:30:10.041	\N	\N
9bb7b249-3c0a-4e0b-8cb5-d22f2b70bcfa	18e007d1-7d3c-41b6-9b4c-900c977bf474	OT	Edit	t	2026-07-11 08:30:10.134	2026-07-11 08:30:10.134	\N	\N
6366c6e1-7db5-46d9-8ccb-5a1882b8d643	18e007d1-7d3c-41b6-9b4c-900c977bf474	OT	Complete	t	2026-07-11 08:30:10.229	2026-07-11 08:30:10.229	\N	\N
ef87d43c-8376-418a-afe3-584839dcf9d9	18e007d1-7d3c-41b6-9b4c-900c977bf474	Pharmacy	View	t	2026-07-11 08:30:10.319	2026-07-11 08:30:10.319	\N	\N
919c08ec-418a-4c4a-bfc3-84d00e72359b	18e007d1-7d3c-41b6-9b4c-900c977bf474	Pharmacy	Create	t	2026-07-11 08:30:10.414	2026-07-11 08:30:10.414	\N	\N
04dc1c10-7d28-40fa-bb3f-e28f18d4ff2e	18e007d1-7d3c-41b6-9b4c-900c977bf474	Pharmacy	Edit	t	2026-07-11 08:30:10.509	2026-07-11 08:30:10.509	\N	\N
2ff4c4eb-f657-45c9-be94-8423ccf36067	18e007d1-7d3c-41b6-9b4c-900c977bf474	Pharmacy	Dispense	t	2026-07-11 08:30:10.607	2026-07-11 08:30:10.607	\N	\N
8d838dea-f29b-4f0b-b0b9-cd7bb91538db	18e007d1-7d3c-41b6-9b4c-900c977bf474	Admin	View	t	2026-07-11 08:30:10.698	2026-07-11 08:30:10.698	\N	\N
b1d33fdc-6057-40eb-899c-72c2db0363a8	18e007d1-7d3c-41b6-9b4c-900c977bf474	Admin	ManageUsers	t	2026-07-11 08:30:11.044	2026-07-11 08:30:11.044	\N	\N
8706b73f-c6cf-4892-a04d-91b47f25919a	18e007d1-7d3c-41b6-9b4c-900c977bf474	Admin	ManagePermissions	t	2026-07-11 08:30:11.14	2026-07-11 08:30:11.14	\N	\N
e1062368-a5ce-482d-9962-204325f67836	18e007d1-7d3c-41b6-9b4c-900c977bf474	Admin	ManageSettings	t	2026-07-11 08:30:11.252	2026-07-11 08:30:11.252	\N	\N
6f636e3a-c78b-4daa-b5c2-1b02854ef231	18e007d1-7d3c-41b6-9b4c-900c977bf474	Admin	ManageTemplates	t	2026-07-11 08:30:11.341	2026-07-11 08:30:11.341	\N	\N
e59e8d03-8498-4443-a7f7-1f768dce41e6	18e007d1-7d3c-41b6-9b4c-900c977bf474	Admin	PublishTemplate	t	2026-07-11 08:30:11.689	2026-07-11 08:30:11.689	\N	\N
117da682-734c-4e19-9088-080a18b238d5	18e007d1-7d3c-41b6-9b4c-900c977bf474	Admin	ManageNumbering	t	2026-07-11 08:30:11.781	2026-07-11 08:30:11.781	\N	\N
28093f91-8818-4ea6-aa35-51e77bb8d365	18e007d1-7d3c-41b6-9b4c-900c977bf474	Admin	Backup	t	2026-07-11 08:30:11.877	2026-07-11 08:30:11.877	\N	\N
026c1d4e-7213-4ffc-a6a5-983e2879ac76	18e007d1-7d3c-41b6-9b4c-900c977bf474	Admin	Restore	t	2026-07-11 08:30:11.966	2026-07-11 08:30:11.966	\N	\N
603b72f8-85d4-4575-809c-8f4f41c0bfad	18e007d1-7d3c-41b6-9b4c-900c977bf474	Admin	ViewAudit	t	2026-07-11 08:30:12.057	2026-07-11 08:30:12.057	\N	\N
fa828ff2-4915-45c0-b2d2-875d1238a486	18e007d1-7d3c-41b6-9b4c-900c977bf474	Admin	Maintenance	t	2026-07-11 08:30:12.397	2026-07-11 08:30:12.397	\N	\N
7f6ae679-7e9e-4b6d-b278-e52853c1c07c	18e007d1-7d3c-41b6-9b4c-900c977bf474	Admin	License	t	2026-07-11 08:30:12.487	2026-07-11 08:30:12.487	\N	\N
58cc5b60-1985-4fe6-8072-59d301faa9b8	18e007d1-7d3c-41b6-9b4c-900c977bf474	Admin	Sessions	t	2026-07-11 08:30:12.584	2026-07-11 08:30:12.584	\N	\N
3b9f98a1-eeed-48d9-8743-f85125a75a8c	18e007d1-7d3c-41b6-9b4c-900c977bf474	Reports	View	t	2026-07-11 08:30:12.674	2026-07-11 08:30:12.674	\N	\N
98910c6a-925a-4d8c-9e36-02caa58f26f8	18e007d1-7d3c-41b6-9b4c-900c977bf474	Reports	Export	t	2026-07-11 08:30:12.763	2026-07-11 08:30:12.763	\N	\N
5e3427b7-bb48-4c37-a200-0deef881ac41	18e007d1-7d3c-41b6-9b4c-900c977bf474	Reports	Print	t	2026-07-11 08:30:12.852	2026-07-11 08:30:12.852	\N	\N
\.


--
-- Data for Name: pharmacy_invoice_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pharmacy_invoice_items (id, "pharmacyInvoiceId", "medicineId", "batchNumber", "quantitySold", "unitPrice", "totalPrice", "gstPercentage", "discountAmount", "createdAt", "updatedAt", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: pharmacy_invoice_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pharmacy_invoice_payments (id, "pharmacyInvoiceId", "paymentMode", amount) FROM stdin;
\.


--
-- Data for Name: pharmacy_invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pharmacy_invoices (id, "pharmacyInvoiceNumber", "customerType", "patientId", "hospitalId", "customerName", "customerPhone", "totalAmount", "discountAmount", "payableAmount", "paymentMode", "receivedBy", status, "cancelledAt", "cancelledBy", "cancellationReason", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: pharmacy_purchase_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pharmacy_purchase_items (id, "purchaseOrderId", "medicineId", "batchNumber", "expiryDate", "quantityReceived", "unitCost", "purchaseRate", "sellingRate", "gstPercentage", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: pharmacy_purchase_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pharmacy_purchase_orders (id, "invoiceNumber", "supplierName", "orderDate", "totalCost", "receivedBy", remarks, "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: pharmacy_return_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pharmacy_return_items (id, "pharmacyReturnId", "medicineId", "batchNumber", "quantityReturned", "refundRate", "totalAmount") FROM stdin;
\.


--
-- Data for Name: pharmacy_returns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pharmacy_returns (id, "pharmacyInvoiceId", "returnNumber", "refundAmount", reason, "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: pharmacy_stock_adjustments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pharmacy_stock_adjustments (id, "medicineId", "batchNumber", "adjustmentType", "stockBefore", quantity, "stockAfter", reason, "employeeId", date, "createdAt", "createdBy") FROM stdin;
\.


--
-- Data for Name: print_histories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.print_histories (id, "documentType", "documentId", "printedById", "printedAt", "templateId", "templateVersion", "requestId", "printedFromModule", "brandingSnapshot") FROM stdin;
\.


--
-- Data for Name: print_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.print_templates (id, "templateKey", name, "layoutJson", "pageFormat", "hospitalId", "documentType", status, version, "isPublished", category, orientation, margins, copies, language, "isSystemDefault", "thumbnailUrl", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: radiology_findings_revisions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.radiology_findings_revisions (id, "scanOrderId", "revisionNumber", findings, remarks, "technicianId", "verifiedById", "completedAt", "completedBy", "editedAt", "editedBy") FROM stdin;
\.


--
-- Data for Name: radiology_scan_catalogs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.radiology_scan_catalogs (id, code, name, category, "standardRate", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: radiology_scan_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.radiology_scan_orders (id, "patientId", "scanCatalogId", "orderedByDoctorId", "opdConsultationId", "ipdAdmissionId", "billableChargeId", status, findings, remarks, "technicianId", "verifiedById", "cancelledAt", "cancelledBy", "cancellationReason", "completedAt", "completedBy", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: refunds; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refunds (id, "invoiceId", "paymentId", "amountRefunded", "refundReason", "refundedAt", "refundedBy", "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
\.


--
-- Data for Name: sequences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sequences ("sequenceName", "currentValue", prefix, "paddingLength", "isActive", description, "lastGeneratedAt") FROM stdin;
PATIENT_UHID_110726	1		5	t	\N	2026-07-11 08:44:43.991
DOCTOR_REG_SEQUENCE_26	1	DOC26	3	t	\N	2026-07-11 08:47:02.341
EMPLOYEE_CODE_SEQUENCE	3	EMP	3	t	\N	2026-07-11 08:47:02.852
OPD_ID_SEQUENCE	1	OPD26	4	t	\N	2026-07-11 08:48:08.492
OPD_TOKEN_fad78794-e7a8-49ea-b461-2fea6eb9b2c6_11072026	1		1	t	\N	2026-07-11 08:48:09.108
INVOICE_NO_SEQUENCE	1	INV26	6	t	\N	2026-07-11 08:48:10.745
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, "userId", "expiresAt", "ipAddress", "userAgent", "isActive", "createdAt", "updatedAt") FROM stdin;
01af20c6a9c6d2c6fad4e00deb6b17a9ab36180173a94cd8188b2b3c8a93f370	18e007d1-7d3c-41b6-9b4c-900c977bf474	2026-07-11 20:32:27.801	::ffff:127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) hms-app/2.0.0 Chrome/148.0.7778.271 Electron/42.5.1 Safari/537.36	t	2026-07-11 08:32:27.806	2026-07-11 08:32:27.806
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (id, "settingKey", "settingValue", "dataType", category, description, "createdAt", "updatedAt", "createdBy", "updatedBy", "isDeleted", "deletedAt", "deletedBy") FROM stdin;
b8981214-4935-453f-bca1-360bd7b72cc8	license_key	1CC52-06F47-E12A6-483A0-84309	STRING	GENERAL	\N	2026-07-11 08:35:56.008	2026-07-11 08:35:56.008	\N	\N	f	\N	\N
3ef0f7ff-a97f-448f-a2ce-1059d1def3ff	license_data	{"expiryDate":"2036-12-31","registeredHospital":"Balaji Hospital","registeredOwner":"Ayush Mishra","version":"2.0.0"}	STRING	GENERAL	\N	2026-07-11 08:35:56.118	2026-07-11 08:35:56.118	\N	\N	f	\N	\N
22923029-1df3-4d67-8bcb-317738545b70	maintenance_block_on_expiry	true	STRING	GENERAL	\N	2026-07-11 08:35:56.172	2026-07-11 08:35:56.172	\N	\N	f	\N	\N
\.


--
-- Data for Name: wards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wards (id, name, code, "floorId", "isDeleted", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-06-26 14:47:23
20211116045059	2026-06-26 14:47:23
20211116050929	2026-06-26 14:47:23
20211116051442	2026-06-26 14:47:23
20211116212300	2026-06-26 14:47:23
20211116213355	2026-06-26 14:47:23
20211116213934	2026-06-26 17:26:11
20211116214523	2026-06-26 17:26:11
20211122062447	2026-06-26 17:26:11
20211124070109	2026-06-26 17:26:11
20211202204204	2026-06-26 17:26:11
20211202204605	2026-06-26 17:26:11
20211210212804	2026-06-26 17:26:11
20211228014915	2026-06-26 17:26:11
20220107221237	2026-06-26 17:26:11
20220228202821	2026-06-26 17:26:11
20220312004840	2026-06-26 17:26:11
20220603231003	2026-06-26 17:26:11
20220603232444	2026-06-26 17:26:11
20220615214548	2026-06-26 17:26:11
20220712093339	2026-06-26 17:26:11
20220908172859	2026-06-26 17:26:11
20220916233421	2026-06-26 17:26:11
20230119133233	2026-06-26 17:26:11
20230128025114	2026-06-26 17:26:11
20230128025212	2026-06-26 17:26:11
20230227211149	2026-06-26 17:26:11
20230228184745	2026-06-26 17:26:11
20230308225145	2026-06-26 17:26:11
20230328144023	2026-06-26 17:26:11
20231018144023	2026-06-26 17:26:11
20231204144023	2026-06-26 17:26:11
20231204144024	2026-06-26 17:26:11
20231204144025	2026-06-26 17:26:11
20240108234812	2026-06-26 17:26:11
20240109165339	2026-06-26 17:26:11
20240227174441	2026-06-26 17:26:11
20240311171622	2026-06-26 17:26:11
20240321100241	2026-06-26 17:26:11
20240401105812	2026-06-26 17:26:12
20240418121054	2026-06-26 17:26:12
20240523004032	2026-06-26 17:26:12
20240618124746	2026-06-26 17:26:12
20240801235015	2026-06-26 17:26:12
20240805133720	2026-06-26 17:26:12
20240827160934	2026-06-26 17:26:12
20240919163303	2026-06-26 17:26:12
20240919163305	2026-06-26 17:26:12
20241019105805	2026-06-26 17:26:12
20241030150047	2026-06-26 17:26:12
20241108114728	2026-06-26 17:26:12
20241121104152	2026-06-26 17:26:12
20241130184212	2026-06-26 17:26:12
20241220035512	2026-06-26 17:26:12
20241220123912	2026-06-26 17:26:12
20241224161212	2026-06-26 17:26:12
20250107150512	2026-06-26 17:26:12
20250110162412	2026-06-26 17:26:12
20250123174212	2026-06-26 17:26:12
20250128220012	2026-06-26 17:26:12
20250506224012	2026-06-26 17:26:12
20250523164012	2026-06-26 17:26:12
20250714121412	2026-06-26 17:26:12
20250905041441	2026-06-26 17:26:12
20251103001201	2026-06-26 17:26:12
20251120212548	2026-06-26 17:26:12
20251120215549	2026-06-26 17:26:12
20260218120000	2026-06-26 17:26:12
20260326120000	2026-06-26 17:26:12
20260514120000	2026-06-26 17:26:12
20260527120000	2026-06-26 17:26:12
20260528120000	2026-06-26 17:26:12
20260603120000	2026-06-26 17:26:12
20260605120000	2026-06-26 17:26:12
20260606110000	2026-06-26 17:26:12
20260616120000	2026-06-26 17:26:12
20260624120000	2026-06-26 17:26:12
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter, selected_columns) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-06-26 14:47:25.128411
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-06-26 14:47:25.181611
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-06-26 14:47:25.186228
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-06-26 14:47:25.214137
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-06-26 14:47:25.226222
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-06-26 14:47:25.22911
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-06-26 14:47:25.233156
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-06-26 14:47:25.236649
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-06-26 14:47:25.239864
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-06-26 14:47:25.243162
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-06-26 14:47:25.246416
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-06-26 14:47:25.249814
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-06-26 14:47:25.253208
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-06-26 14:47:25.25644
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-06-26 14:47:25.259761
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-06-26 14:47:25.28392
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-06-26 14:47:25.287552
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-06-26 14:47:25.291067
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-06-26 14:47:25.294516
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-06-26 14:47:25.298948
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-06-26 14:47:25.30236
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-06-26 14:47:25.306984
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-06-26 14:47:25.319568
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-06-26 14:47:25.327767
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-06-26 14:47:25.330946
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-06-26 14:47:25.334098
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-06-26 14:47:25.337332
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-06-26 14:47:25.340106
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-06-26 14:47:25.342796
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-06-26 14:47:25.345648
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-06-26 14:47:25.348558
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-06-26 14:47:25.351327
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-06-26 14:47:25.354268
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-06-26 14:47:25.357131
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-06-26 14:47:25.359908
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-06-26 14:47:25.362738
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-06-26 14:47:25.366071
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-06-26 14:47:25.368911
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-06-26 14:47:25.372573
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-06-26 14:47:25.382253
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-06-26 14:47:25.385094
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-06-26 14:47:25.387974
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-06-26 14:47:25.390803
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-06-26 14:47:25.393665
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-06-26 14:47:25.396497
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-06-26 14:47:25.399999
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-06-26 14:47:25.409208
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-06-26 14:47:25.412558
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-06-26 14:47:25.415343
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-06-26 14:47:25.428862
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-06-26 14:47:25.432487
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-06-26 14:47:26.030863
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-06-26 14:47:26.032593
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-06-26 14:47:26.041355
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-06-26 14:47:26.043318
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-06-26 14:47:26.044783
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-06-26 14:47:26.048408
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-06-26 14:47:26.053015
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-06-26 14:47:26.056276
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-06-26 14:47:26.060095
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-06-26 14:47:26.06326
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: audits audits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audits
    ADD CONSTRAINT audits_pkey PRIMARY KEY (id);


--
-- Name: bed_rooms bed_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bed_rooms
    ADD CONSTRAINT bed_rooms_pkey PRIMARY KEY (id);


--
-- Name: bed_transfer_history bed_transfer_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bed_transfer_history
    ADD CONSTRAINT bed_transfer_history_pkey PRIMARY KEY (id);


--
-- Name: beds beds_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT beds_pkey PRIMARY KEY (id);


--
-- Name: billable_charges billable_charges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billable_charges
    ADD CONSTRAINT billable_charges_pkey PRIMARY KEY (id);


--
-- Name: birth_registrations birth_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.birth_registrations
    ADD CONSTRAINT birth_registrations_pkey PRIMARY KEY (id);


--
-- Name: buildings buildings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buildings
    ADD CONSTRAINT buildings_pkey PRIMARY KEY (id);


--
-- Name: charge_catalogs charge_catalogs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.charge_catalogs
    ADD CONSTRAINT charge_catalogs_pkey PRIMARY KEY (id);


--
-- Name: death_registrations death_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.death_registrations
    ADD CONSTRAINT death_registrations_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: discharge_summary_revisions discharge_summary_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discharge_summary_revisions
    ADD CONSTRAINT discharge_summary_revisions_pkey PRIMARY KEY (id);


--
-- Name: doctor_assignment_history doctor_assignment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_assignment_history
    ADD CONSTRAINT doctor_assignment_history_pkey PRIMARY KEY (id);


--
-- Name: doctors doctors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: floors floors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.floors
    ADD CONSTRAINT floors_pkey PRIMARY KEY (id);


--
-- Name: hospitals hospitals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hospitals
    ADD CONSTRAINT hospitals_pkey PRIMARY KEY (id);


--
-- Name: invoice_charge_mappings invoice_charge_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_charge_mappings
    ADD CONSTRAINT invoice_charge_mappings_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: ipd_admissions ipd_admissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_admissions
    ADD CONSTRAINT ipd_admissions_pkey PRIMARY KEY (id);


--
-- Name: ipd_attendants ipd_attendants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_attendants
    ADD CONSTRAINT ipd_attendants_pkey PRIMARY KEY (id);


--
-- Name: ipd_clinical_attachments ipd_clinical_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_clinical_attachments
    ADD CONSTRAINT ipd_clinical_attachments_pkey PRIMARY KEY (id);


--
-- Name: ipd_consultations_clinical ipd_consultations_clinical_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_consultations_clinical
    ADD CONSTRAINT ipd_consultations_clinical_pkey PRIMARY KEY (id);


--
-- Name: ipd_doctor_rounds ipd_doctor_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_doctor_rounds
    ADD CONSTRAINT ipd_doctor_rounds_pkey PRIMARY KEY (id);


--
-- Name: ipd_handovers ipd_handovers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_handovers
    ADD CONSTRAINT ipd_handovers_pkey PRIMARY KEY (id);


--
-- Name: ipd_intake_output ipd_intake_output_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_intake_output
    ADD CONSTRAINT ipd_intake_output_pkey PRIMARY KEY (id);


--
-- Name: ipd_nursing_tasks ipd_nursing_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_nursing_tasks
    ADD CONSTRAINT ipd_nursing_tasks_pkey PRIMARY KEY (id);


--
-- Name: ipd_progress_notes ipd_progress_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_progress_notes
    ADD CONSTRAINT ipd_progress_notes_pkey PRIMARY KEY (id);


--
-- Name: ipd_timeline_events ipd_timeline_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_timeline_events
    ADD CONSTRAINT ipd_timeline_events_pkey PRIMARY KEY (id);


--
-- Name: ipd_treatment_orders ipd_treatment_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_treatment_orders
    ADD CONSTRAINT ipd_treatment_orders_pkey PRIMARY KEY (id);


--
-- Name: ipd_vitals ipd_vitals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_vitals
    ADD CONSTRAINT ipd_vitals_pkey PRIMARY KEY (id);


--
-- Name: lab_result_revisions lab_result_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lab_result_revisions
    ADD CONSTRAINT lab_result_revisions_pkey PRIMARY KEY (id);


--
-- Name: lab_test_catalogs lab_test_catalogs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lab_test_catalogs
    ADD CONSTRAINT lab_test_catalogs_pkey PRIMARY KEY (id);


--
-- Name: lab_test_orders lab_test_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lab_test_orders
    ADD CONSTRAINT lab_test_orders_pkey PRIMARY KEY (id);


--
-- Name: lab_test_results lab_test_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lab_test_results
    ADD CONSTRAINT lab_test_results_pkey PRIMARY KEY (id);


--
-- Name: medicine_stocks medicine_stocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicine_stocks
    ADD CONSTRAINT medicine_stocks_pkey PRIMARY KEY (id);


--
-- Name: medicines medicines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicines
    ADD CONSTRAINT medicines_pkey PRIMARY KEY (id);


--
-- Name: opd_consultations opd_consultations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opd_consultations
    ADD CONSTRAINT opd_consultations_pkey PRIMARY KEY (id);


--
-- Name: operation_theater_revisions operation_theater_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_theater_revisions
    ADD CONSTRAINT operation_theater_revisions_pkey PRIMARY KEY (id);


--
-- Name: operation_theaters operation_theaters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_theaters
    ADD CONSTRAINT operation_theaters_pkey PRIMARY KEY (id);


--
-- Name: patient_addresses patient_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_addresses
    ADD CONSTRAINT patient_addresses_pkey PRIMARY KEY (id);


--
-- Name: patient_deposit_allocations patient_deposit_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_deposit_allocations
    ADD CONSTRAINT patient_deposit_allocations_pkey PRIMARY KEY (id);


--
-- Name: patient_deposits patient_deposits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_deposits
    ADD CONSTRAINT patient_deposits_pkey PRIMARY KEY (id);


--
-- Name: patient_emergency_contacts patient_emergency_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_emergency_contacts
    ADD CONSTRAINT patient_emergency_contacts_pkey PRIMARY KEY (id);


--
-- Name: patient_referrals patient_referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_referrals
    ADD CONSTRAINT patient_referrals_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_invoice_items pharmacy_invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_invoice_items
    ADD CONSTRAINT pharmacy_invoice_items_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_invoice_payments pharmacy_invoice_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_invoice_payments
    ADD CONSTRAINT pharmacy_invoice_payments_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_invoices pharmacy_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_invoices
    ADD CONSTRAINT pharmacy_invoices_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_purchase_items pharmacy_purchase_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_purchase_items
    ADD CONSTRAINT pharmacy_purchase_items_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_purchase_orders pharmacy_purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_purchase_orders
    ADD CONSTRAINT pharmacy_purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_return_items pharmacy_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_return_items
    ADD CONSTRAINT pharmacy_return_items_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_returns pharmacy_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_returns
    ADD CONSTRAINT pharmacy_returns_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_stock_adjustments pharmacy_stock_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_stock_adjustments
    ADD CONSTRAINT pharmacy_stock_adjustments_pkey PRIMARY KEY (id);


--
-- Name: print_histories print_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.print_histories
    ADD CONSTRAINT print_histories_pkey PRIMARY KEY (id);


--
-- Name: print_templates print_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.print_templates
    ADD CONSTRAINT print_templates_pkey PRIMARY KEY (id);


--
-- Name: radiology_findings_revisions radiology_findings_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.radiology_findings_revisions
    ADD CONSTRAINT radiology_findings_revisions_pkey PRIMARY KEY (id);


--
-- Name: radiology_scan_catalogs radiology_scan_catalogs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.radiology_scan_catalogs
    ADD CONSTRAINT radiology_scan_catalogs_pkey PRIMARY KEY (id);


--
-- Name: radiology_scan_orders radiology_scan_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.radiology_scan_orders
    ADD CONSTRAINT radiology_scan_orders_pkey PRIMARY KEY (id);


--
-- Name: refunds refunds_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_pkey PRIMARY KEY (id);


--
-- Name: sequences sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sequences
    ADD CONSTRAINT sequences_pkey PRIMARY KEY ("sequenceName");


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: wards wards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wards
    ADD CONSTRAINT wards_pkey PRIMARY KEY (id);


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages
    ADD CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL))) NOT VALID;


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_created_at_desc ON auth.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_last_sign_in_at_desc ON auth.users USING btree (last_sign_in_at DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_name ON auth.users USING btree (((raw_user_meta_data ->> 'name'::text))) WHERE ((raw_user_meta_data ->> 'name'::text) IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: audits_action_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audits_action_idx ON public.audits USING btree (action);


--
-- Name: audits_resource_entityId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "audits_resource_entityId_idx" ON public.audits USING btree (resource, "entityId");


--
-- Name: audits_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audits_timestamp_idx ON public.audits USING btree ("timestamp");


--
-- Name: audits_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "audits_userId_idx" ON public.audits USING btree ("userId");


--
-- Name: bed_rooms_roomNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "bed_rooms_roomNumber_key" ON public.bed_rooms USING btree ("roomNumber");


--
-- Name: beds_roomId_bedNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "beds_roomId_bedNumber_key" ON public.beds USING btree ("roomId", "bedNumber");


--
-- Name: billable_charges_billingStatus_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "billable_charges_billingStatus_idx" ON public.billable_charges USING btree ("billingStatus");


--
-- Name: billable_charges_patientId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "billable_charges_patientId_createdAt_idx" ON public.billable_charges USING btree ("patientId", "createdAt");


--
-- Name: billable_charges_patientId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "billable_charges_patientId_idx" ON public.billable_charges USING btree ("patientId");


--
-- Name: billable_charges_sourceModule_sourceEntityId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "billable_charges_sourceModule_sourceEntityId_idx" ON public.billable_charges USING btree ("sourceModule", "sourceEntityId");


--
-- Name: birth_registrations_certificateNumber_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "birth_registrations_certificateNumber_idx" ON public.birth_registrations USING btree ("certificateNumber");


--
-- Name: birth_registrations_certificateNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "birth_registrations_certificateNumber_key" ON public.birth_registrations USING btree ("certificateNumber");


--
-- Name: birth_registrations_hospitalId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "birth_registrations_hospitalId_idx" ON public.birth_registrations USING btree ("hospitalId");


--
-- Name: birth_registrations_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "birth_registrations_ipdAdmissionId_idx" ON public.birth_registrations USING btree ("ipdAdmissionId");


--
-- Name: buildings_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX buildings_code_key ON public.buildings USING btree (code);


--
-- Name: charge_catalogs_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX charge_catalogs_code_key ON public.charge_catalogs USING btree (code);


--
-- Name: death_registrations_certificateNumber_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "death_registrations_certificateNumber_idx" ON public.death_registrations USING btree ("certificateNumber");


--
-- Name: death_registrations_certificateNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "death_registrations_certificateNumber_key" ON public.death_registrations USING btree ("certificateNumber");


--
-- Name: death_registrations_hospitalId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "death_registrations_hospitalId_idx" ON public.death_registrations USING btree ("hospitalId");


--
-- Name: death_registrations_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "death_registrations_ipdAdmissionId_idx" ON public.death_registrations USING btree ("ipdAdmissionId");


--
-- Name: death_registrations_patientId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "death_registrations_patientId_idx" ON public.death_registrations USING btree ("patientId");


--
-- Name: departments_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX departments_code_key ON public.departments USING btree (code);


--
-- Name: discharge_summary_revisions_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "discharge_summary_revisions_ipdAdmissionId_idx" ON public.discharge_summary_revisions USING btree ("ipdAdmissionId");


--
-- Name: doctors_registrationNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "doctors_registrationNumber_key" ON public.doctors USING btree ("registrationNumber");


--
-- Name: employees_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employees_email_idx ON public.employees USING btree (email);


--
-- Name: employees_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX employees_email_key ON public.employees USING btree (email);


--
-- Name: employees_employeeCode_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "employees_employeeCode_key" ON public.employees USING btree ("employeeCode");


--
-- Name: employees_hospitalId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "employees_hospitalId_idx" ON public.employees USING btree ("hospitalId");


--
-- Name: employees_role_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX employees_role_idx ON public.employees USING btree (role);


--
-- Name: hospitals_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX hospitals_code_key ON public.hospitals USING btree (code);


--
-- Name: invoice_charge_mappings_invoiceId_billableChargeId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoice_charge_mappings_invoiceId_billableChargeId_key" ON public.invoice_charge_mappings USING btree ("invoiceId", "billableChargeId");


--
-- Name: invoices_hospitalId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_hospitalId_idx" ON public.invoices USING btree ("hospitalId");


--
-- Name: invoices_invoiceNumber_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_invoiceNumber_idx" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_invoiceNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoices_invoiceNumber_key" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_invoiceNumber_paymentStatus_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_invoiceNumber_paymentStatus_idx" ON public.invoices USING btree ("invoiceNumber", "paymentStatus");


--
-- Name: invoices_patientId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_patientId_createdAt_idx" ON public.invoices USING btree ("patientId", "createdAt");


--
-- Name: invoices_patientId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_patientId_idx" ON public.invoices USING btree ("patientId");


--
-- Name: invoices_paymentStatus_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "invoices_paymentStatus_idx" ON public.invoices USING btree ("paymentStatus");


--
-- Name: ipd_admissions_admissionDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_admissions_admissionDate_idx" ON public.ipd_admissions USING btree ("admissionDate");


--
-- Name: ipd_admissions_bedId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_admissions_bedId_idx" ON public.ipd_admissions USING btree ("bedId");


--
-- Name: ipd_admissions_hospitalId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_admissions_hospitalId_idx" ON public.ipd_admissions USING btree ("hospitalId");


--
-- Name: ipd_admissions_ipdId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_admissions_ipdId_idx" ON public.ipd_admissions USING btree ("ipdId");


--
-- Name: ipd_admissions_ipdId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ipd_admissions_ipdId_key" ON public.ipd_admissions USING btree ("ipdId");


--
-- Name: ipd_admissions_patientId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_admissions_patientId_idx" ON public.ipd_admissions USING btree ("patientId");


--
-- Name: ipd_attendants_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_attendants_ipdAdmissionId_idx" ON public.ipd_attendants USING btree ("ipdAdmissionId");


--
-- Name: ipd_clinical_attachments_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_clinical_attachments_ipdAdmissionId_idx" ON public.ipd_clinical_attachments USING btree ("ipdAdmissionId");


--
-- Name: ipd_consultations_clinical_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_consultations_clinical_ipdAdmissionId_idx" ON public.ipd_consultations_clinical USING btree ("ipdAdmissionId");


--
-- Name: ipd_consultations_clinical_targetDepartmentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_consultations_clinical_targetDepartmentId_idx" ON public.ipd_consultations_clinical USING btree ("targetDepartmentId");


--
-- Name: ipd_consultations_clinical_targetDoctorId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_consultations_clinical_targetDoctorId_idx" ON public.ipd_consultations_clinical USING btree ("targetDoctorId");


--
-- Name: ipd_doctor_rounds_doctorId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_doctor_rounds_doctorId_idx" ON public.ipd_doctor_rounds USING btree ("doctorId");


--
-- Name: ipd_doctor_rounds_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_doctor_rounds_ipdAdmissionId_idx" ON public.ipd_doctor_rounds USING btree ("ipdAdmissionId");


--
-- Name: ipd_handovers_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_handovers_ipdAdmissionId_idx" ON public.ipd_handovers USING btree ("ipdAdmissionId");


--
-- Name: ipd_handovers_recipientUserId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_handovers_recipientUserId_idx" ON public.ipd_handovers USING btree ("recipientUserId");


--
-- Name: ipd_intake_output_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_intake_output_ipdAdmissionId_idx" ON public.ipd_intake_output USING btree ("ipdAdmissionId");


--
-- Name: ipd_nursing_tasks_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_nursing_tasks_ipdAdmissionId_idx" ON public.ipd_nursing_tasks USING btree ("ipdAdmissionId");


--
-- Name: ipd_progress_notes_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_progress_notes_ipdAdmissionId_idx" ON public.ipd_progress_notes USING btree ("ipdAdmissionId");


--
-- Name: ipd_timeline_events_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_timeline_events_ipdAdmissionId_idx" ON public.ipd_timeline_events USING btree ("ipdAdmissionId");


--
-- Name: ipd_treatment_orders_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_treatment_orders_ipdAdmissionId_idx" ON public.ipd_treatment_orders USING btree ("ipdAdmissionId");


--
-- Name: ipd_vitals_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ipd_vitals_ipdAdmissionId_idx" ON public.ipd_vitals USING btree ("ipdAdmissionId");


--
-- Name: lab_result_revisions_testOrderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "lab_result_revisions_testOrderId_idx" ON public.lab_result_revisions USING btree ("testOrderId");


--
-- Name: lab_test_catalogs_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX lab_test_catalogs_code_key ON public.lab_test_catalogs USING btree (code);


--
-- Name: lab_test_orders_hospitalId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "lab_test_orders_hospitalId_idx" ON public.lab_test_orders USING btree ("hospitalId");


--
-- Name: lab_test_orders_patientId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "lab_test_orders_patientId_createdAt_idx" ON public.lab_test_orders USING btree ("patientId", "createdAt");


--
-- Name: lab_test_orders_patientId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "lab_test_orders_patientId_idx" ON public.lab_test_orders USING btree ("patientId");


--
-- Name: lab_test_orders_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX lab_test_orders_status_idx ON public.lab_test_orders USING btree (status);


--
-- Name: lab_test_results_testOrderId_parameterName_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "lab_test_results_testOrderId_parameterName_key" ON public.lab_test_results USING btree ("testOrderId", "parameterName");


--
-- Name: medicine_stocks_expiryDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "medicine_stocks_expiryDate_idx" ON public.medicine_stocks USING btree ("expiryDate");


--
-- Name: medicine_stocks_medicineId_batchNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "medicine_stocks_medicineId_batchNumber_key" ON public.medicine_stocks USING btree ("medicineId", "batchNumber");


--
-- Name: medicine_stocks_medicineId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "medicine_stocks_medicineId_idx" ON public.medicine_stocks USING btree ("medicineId");


--
-- Name: medicines_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX medicines_code_idx ON public.medicines USING btree (code);


--
-- Name: medicines_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX medicines_code_key ON public.medicines USING btree (code);


--
-- Name: medicines_genericName_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "medicines_genericName_idx" ON public.medicines USING btree ("genericName");


--
-- Name: medicines_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX medicines_name_idx ON public.medicines USING btree (name);


--
-- Name: opd_consultations_consultationDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "opd_consultations_consultationDate_idx" ON public.opd_consultations USING btree ("consultationDate");


--
-- Name: opd_consultations_doctorId_consultationDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "opd_consultations_doctorId_consultationDate_idx" ON public.opd_consultations USING btree ("doctorId", "consultationDate");


--
-- Name: opd_consultations_doctorId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "opd_consultations_doctorId_idx" ON public.opd_consultations USING btree ("doctorId");


--
-- Name: opd_consultations_hospitalId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "opd_consultations_hospitalId_idx" ON public.opd_consultations USING btree ("hospitalId");


--
-- Name: opd_consultations_opdId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "opd_consultations_opdId_idx" ON public.opd_consultations USING btree ("opdId");


--
-- Name: opd_consultations_opdId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "opd_consultations_opdId_key" ON public.opd_consultations USING btree ("opdId");


--
-- Name: opd_consultations_patientId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "opd_consultations_patientId_idx" ON public.opd_consultations USING btree ("patientId");


--
-- Name: operation_theater_revisions_operationTheaterId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "operation_theater_revisions_operationTheaterId_idx" ON public.operation_theater_revisions USING btree ("operationTheaterId");


--
-- Name: operation_theaters_hospitalId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "operation_theaters_hospitalId_idx" ON public.operation_theaters USING btree ("hospitalId");


--
-- Name: operation_theaters_ipdAdmissionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "operation_theaters_ipdAdmissionId_idx" ON public.operation_theaters USING btree ("ipdAdmissionId");


--
-- Name: operation_theaters_opdConsultationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "operation_theaters_opdConsultationId_idx" ON public.operation_theaters USING btree ("opdConsultationId");


--
-- Name: operation_theaters_otId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "operation_theaters_otId_idx" ON public.operation_theaters USING btree ("otId");


--
-- Name: operation_theaters_otId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "operation_theaters_otId_key" ON public.operation_theaters USING btree ("otId");


--
-- Name: operation_theaters_scheduledDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "operation_theaters_scheduledDate_idx" ON public.operation_theaters USING btree ("scheduledDate");


--
-- Name: patient_addresses_patientId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "patient_addresses_patientId_key" ON public.patient_addresses USING btree ("patientId");


--
-- Name: patient_deposit_allocations_depositId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "patient_deposit_allocations_depositId_idx" ON public.patient_deposit_allocations USING btree ("depositId");


--
-- Name: patient_deposit_allocations_invoiceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "patient_deposit_allocations_invoiceId_idx" ON public.patient_deposit_allocations USING btree ("invoiceId");


--
-- Name: patient_emergency_contacts_patientId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "patient_emergency_contacts_patientId_key" ON public.patient_emergency_contacts USING btree ("patientId");


--
-- Name: patients_aadhaarNumber_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "patients_aadhaarNumber_idx" ON public.patients USING btree ("aadhaarNumber");


--
-- Name: patients_aadhaarNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "patients_aadhaarNumber_key" ON public.patients USING btree ("aadhaarNumber");


--
-- Name: patients_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "patients_createdAt_idx" ON public.patients USING btree ("createdAt");


--
-- Name: patients_hospitalId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "patients_hospitalId_idx" ON public.patients USING btree ("hospitalId");


--
-- Name: patients_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX patients_name_idx ON public.patients USING btree (name);


--
-- Name: patients_phone_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX patients_phone_idx ON public.patients USING btree (phone);


--
-- Name: patients_uhid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX patients_uhid_idx ON public.patients USING btree (uhid);


--
-- Name: patients_uhid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX patients_uhid_key ON public.patients USING btree (uhid);


--
-- Name: payments_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "payments_createdAt_idx" ON public.payments USING btree ("createdAt");


--
-- Name: payments_invoiceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "payments_invoiceId_idx" ON public.payments USING btree ("invoiceId");


--
-- Name: payments_receivedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "payments_receivedAt_idx" ON public.payments USING btree ("receivedAt");


--
-- Name: permissions_userId_module_action_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "permissions_userId_module_action_key" ON public.permissions USING btree ("userId", module, action);


--
-- Name: pharmacy_invoices_hospitalId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pharmacy_invoices_hospitalId_idx" ON public.pharmacy_invoices USING btree ("hospitalId");


--
-- Name: pharmacy_invoices_patientId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pharmacy_invoices_patientId_idx" ON public.pharmacy_invoices USING btree ("patientId");


--
-- Name: pharmacy_invoices_pharmacyInvoiceNumber_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pharmacy_invoices_pharmacyInvoiceNumber_idx" ON public.pharmacy_invoices USING btree ("pharmacyInvoiceNumber");


--
-- Name: pharmacy_invoices_pharmacyInvoiceNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "pharmacy_invoices_pharmacyInvoiceNumber_key" ON public.pharmacy_invoices USING btree ("pharmacyInvoiceNumber");


--
-- Name: pharmacy_returns_returnNumber_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "pharmacy_returns_returnNumber_idx" ON public.pharmacy_returns USING btree ("returnNumber");


--
-- Name: pharmacy_returns_returnNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "pharmacy_returns_returnNumber_key" ON public.pharmacy_returns USING btree ("returnNumber");


--
-- Name: print_templates_hospitalId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "print_templates_hospitalId_idx" ON public.print_templates USING btree ("hospitalId");


--
-- Name: print_templates_templateKey_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "print_templates_templateKey_idx" ON public.print_templates USING btree ("templateKey");


--
-- Name: radiology_findings_revisions_scanOrderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "radiology_findings_revisions_scanOrderId_idx" ON public.radiology_findings_revisions USING btree ("scanOrderId");


--
-- Name: radiology_scan_catalogs_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX radiology_scan_catalogs_code_key ON public.radiology_scan_catalogs USING btree (code);


--
-- Name: radiology_scan_orders_patientId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "radiology_scan_orders_patientId_idx" ON public.radiology_scan_orders USING btree ("patientId");


--
-- Name: radiology_scan_orders_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX radiology_scan_orders_status_idx ON public.radiology_scan_orders USING btree (status);


--
-- Name: refunds_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "refunds_createdAt_idx" ON public.refunds USING btree ("createdAt");


--
-- Name: refunds_invoiceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "refunds_invoiceId_idx" ON public.refunds USING btree ("invoiceId");


--
-- Name: refunds_refundedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "refunds_refundedAt_idx" ON public.refunds USING btree ("refundedAt");


--
-- Name: sessions_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "sessions_expiresAt_idx" ON public.sessions USING btree ("expiresAt");


--
-- Name: sessions_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "sessions_userId_idx" ON public.sessions USING btree ("userId");


--
-- Name: system_settings_settingKey_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "system_settings_settingKey_key" ON public.system_settings USING btree ("settingKey");


--
-- Name: wards_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX wards_code_key ON public.wards USING btree (code);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_action_filter_selec ON realtime.subscription USING btree (subscription_id, entity, filters, action_filter, COALESCE(selected_columns, '{}'::text[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name_lower ON storage.objects USING btree (bucket_id, lower(name) COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER protect_buckets_delete BEFORE DELETE ON storage.buckets FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER protect_objects_delete BEFORE DELETE ON storage.objects FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: audits audits_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audits
    ADD CONSTRAINT "audits_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bed_rooms bed_rooms_wardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bed_rooms
    ADD CONSTRAINT "bed_rooms_wardId_fkey" FOREIGN KEY ("wardId") REFERENCES public.wards(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bed_transfer_history bed_transfer_history_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bed_transfer_history
    ADD CONSTRAINT "bed_transfer_history_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bed_transfer_history bed_transfer_history_newBedId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bed_transfer_history
    ADD CONSTRAINT "bed_transfer_history_newBedId_fkey" FOREIGN KEY ("newBedId") REFERENCES public.beds(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bed_transfer_history bed_transfer_history_previousBedId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bed_transfer_history
    ADD CONSTRAINT "bed_transfer_history_previousBedId_fkey" FOREIGN KEY ("previousBedId") REFERENCES public.beds(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bed_transfer_history bed_transfer_history_transferredBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bed_transfer_history
    ADD CONSTRAINT "bed_transfer_history_transferredBy_fkey" FOREIGN KEY ("transferredBy") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: beds beds_roomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT "beds_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES public.bed_rooms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: billable_charges billable_charges_chargeCatalogId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billable_charges
    ADD CONSTRAINT "billable_charges_chargeCatalogId_fkey" FOREIGN KEY ("chargeCatalogId") REFERENCES public.charge_catalogs(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: billable_charges billable_charges_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billable_charges
    ADD CONSTRAINT "billable_charges_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: birth_registrations birth_registrations_attendingDoctorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.birth_registrations
    ADD CONSTRAINT "birth_registrations_attendingDoctorId_fkey" FOREIGN KEY ("attendingDoctorId") REFERENCES public.doctors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: birth_registrations birth_registrations_hospitalId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.birth_registrations
    ADD CONSTRAINT "birth_registrations_hospitalId_fkey" FOREIGN KEY ("hospitalId") REFERENCES public.hospitals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: birth_registrations birth_registrations_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.birth_registrations
    ADD CONSTRAINT "birth_registrations_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: birth_registrations birth_registrations_motherPatientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.birth_registrations
    ADD CONSTRAINT "birth_registrations_motherPatientId_fkey" FOREIGN KEY ("motherPatientId") REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: death_registrations death_registrations_attendingDoctorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.death_registrations
    ADD CONSTRAINT "death_registrations_attendingDoctorId_fkey" FOREIGN KEY ("attendingDoctorId") REFERENCES public.doctors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: death_registrations death_registrations_hospitalId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.death_registrations
    ADD CONSTRAINT "death_registrations_hospitalId_fkey" FOREIGN KEY ("hospitalId") REFERENCES public.hospitals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: death_registrations death_registrations_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.death_registrations
    ADD CONSTRAINT "death_registrations_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: death_registrations death_registrations_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.death_registrations
    ADD CONSTRAINT "death_registrations_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: discharge_summary_revisions discharge_summary_revisions_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discharge_summary_revisions
    ADD CONSTRAINT "discharge_summary_revisions_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doctor_assignment_history doctor_assignment_history_assignedDoctorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_assignment_history
    ADD CONSTRAINT "doctor_assignment_history_assignedDoctorId_fkey" FOREIGN KEY ("assignedDoctorId") REFERENCES public.doctors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: doctor_assignment_history doctor_assignment_history_changedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_assignment_history
    ADD CONSTRAINT "doctor_assignment_history_changedBy_fkey" FOREIGN KEY ("changedBy") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: doctor_assignment_history doctor_assignment_history_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_assignment_history
    ADD CONSTRAINT "doctor_assignment_history_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doctor_assignment_history doctor_assignment_history_previousDoctorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_assignment_history
    ADD CONSTRAINT "doctor_assignment_history_previousDoctorId_fkey" FOREIGN KEY ("previousDoctorId") REFERENCES public.doctors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: doctors doctors_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctors
    ADD CONSTRAINT doctors_id_fkey FOREIGN KEY (id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: employees employees_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT "employees_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: employees employees_hospitalId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT "employees_hospitalId_fkey" FOREIGN KEY ("hospitalId") REFERENCES public.hospitals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: floors floors_buildingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.floors
    ADD CONSTRAINT "floors_buildingId_fkey" FOREIGN KEY ("buildingId") REFERENCES public.buildings(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoice_charge_mappings invoice_charge_mappings_billableChargeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_charge_mappings
    ADD CONSTRAINT "invoice_charge_mappings_billableChargeId_fkey" FOREIGN KEY ("billableChargeId") REFERENCES public.billable_charges(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoice_charge_mappings invoice_charge_mappings_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_charge_mappings
    ADD CONSTRAINT "invoice_charge_mappings_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoices invoices_cancelledBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_cancelledBy_fkey" FOREIGN KEY ("cancelledBy") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoices invoices_hospitalId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_hospitalId_fkey" FOREIGN KEY ("hospitalId") REFERENCES public.hospitals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoices invoices_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_admissions ipd_admissions_bedId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_admissions
    ADD CONSTRAINT "ipd_admissions_bedId_fkey" FOREIGN KEY ("bedId") REFERENCES public.beds(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_admissions ipd_admissions_cancelledBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_admissions
    ADD CONSTRAINT "ipd_admissions_cancelledBy_fkey" FOREIGN KEY ("cancelledBy") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_admissions ipd_admissions_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_admissions
    ADD CONSTRAINT "ipd_admissions_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_admissions ipd_admissions_dischargeBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_admissions
    ADD CONSTRAINT "ipd_admissions_dischargeBy_fkey" FOREIGN KEY ("dischargeBy") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_admissions ipd_admissions_hospitalId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_admissions
    ADD CONSTRAINT "ipd_admissions_hospitalId_fkey" FOREIGN KEY ("hospitalId") REFERENCES public.hospitals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_admissions ipd_admissions_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_admissions
    ADD CONSTRAINT "ipd_admissions_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_admissions ipd_admissions_primaryDoctorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_admissions
    ADD CONSTRAINT "ipd_admissions_primaryDoctorId_fkey" FOREIGN KEY ("primaryDoctorId") REFERENCES public.doctors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_admissions ipd_admissions_referredByDoctorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_admissions
    ADD CONSTRAINT "ipd_admissions_referredByDoctorId_fkey" FOREIGN KEY ("referredByDoctorId") REFERENCES public.doctors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_attendants ipd_attendants_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_attendants
    ADD CONSTRAINT "ipd_attendants_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_clinical_attachments ipd_clinical_attachments_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_clinical_attachments
    ADD CONSTRAINT "ipd_clinical_attachments_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_consultations_clinical ipd_consultations_clinical_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_consultations_clinical
    ADD CONSTRAINT "ipd_consultations_clinical_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_consultations_clinical ipd_consultations_clinical_targetDepartmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_consultations_clinical
    ADD CONSTRAINT "ipd_consultations_clinical_targetDepartmentId_fkey" FOREIGN KEY ("targetDepartmentId") REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_consultations_clinical ipd_consultations_clinical_targetDoctorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_consultations_clinical
    ADD CONSTRAINT "ipd_consultations_clinical_targetDoctorId_fkey" FOREIGN KEY ("targetDoctorId") REFERENCES public.doctors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_doctor_rounds ipd_doctor_rounds_doctorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_doctor_rounds
    ADD CONSTRAINT "ipd_doctor_rounds_doctorId_fkey" FOREIGN KEY ("doctorId") REFERENCES public.doctors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_doctor_rounds ipd_doctor_rounds_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_doctor_rounds
    ADD CONSTRAINT "ipd_doctor_rounds_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_handovers ipd_handovers_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_handovers
    ADD CONSTRAINT "ipd_handovers_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_handovers ipd_handovers_recipientUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_handovers
    ADD CONSTRAINT "ipd_handovers_recipientUserId_fkey" FOREIGN KEY ("recipientUserId") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_intake_output ipd_intake_output_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_intake_output
    ADD CONSTRAINT "ipd_intake_output_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_nursing_tasks ipd_nursing_tasks_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_nursing_tasks
    ADD CONSTRAINT "ipd_nursing_tasks_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_progress_notes ipd_progress_notes_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_progress_notes
    ADD CONSTRAINT "ipd_progress_notes_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_timeline_events ipd_timeline_events_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_timeline_events
    ADD CONSTRAINT "ipd_timeline_events_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_treatment_orders ipd_treatment_orders_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_treatment_orders
    ADD CONSTRAINT "ipd_treatment_orders_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ipd_vitals ipd_vitals_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ipd_vitals
    ADD CONSTRAINT "ipd_vitals_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lab_result_revisions lab_result_revisions_testOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lab_result_revisions
    ADD CONSTRAINT "lab_result_revisions_testOrderId_fkey" FOREIGN KEY ("testOrderId") REFERENCES public.lab_test_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lab_test_orders lab_test_orders_hospitalId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lab_test_orders
    ADD CONSTRAINT "lab_test_orders_hospitalId_fkey" FOREIGN KEY ("hospitalId") REFERENCES public.hospitals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lab_test_orders lab_test_orders_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lab_test_orders
    ADD CONSTRAINT "lab_test_orders_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: lab_test_orders lab_test_orders_opdConsultationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lab_test_orders
    ADD CONSTRAINT "lab_test_orders_opdConsultationId_fkey" FOREIGN KEY ("opdConsultationId") REFERENCES public.opd_consultations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: lab_test_orders lab_test_orders_orderedByDoctorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lab_test_orders
    ADD CONSTRAINT "lab_test_orders_orderedByDoctorId_fkey" FOREIGN KEY ("orderedByDoctorId") REFERENCES public.doctors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lab_test_orders lab_test_orders_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lab_test_orders
    ADD CONSTRAINT "lab_test_orders_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lab_test_orders lab_test_orders_testCatalogId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lab_test_orders
    ADD CONSTRAINT "lab_test_orders_testCatalogId_fkey" FOREIGN KEY ("testCatalogId") REFERENCES public.lab_test_catalogs(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lab_test_results lab_test_results_testOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lab_test_results
    ADD CONSTRAINT "lab_test_results_testOrderId_fkey" FOREIGN KEY ("testOrderId") REFERENCES public.lab_test_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: medicine_stocks medicine_stocks_medicineId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicine_stocks
    ADD CONSTRAINT "medicine_stocks_medicineId_fkey" FOREIGN KEY ("medicineId") REFERENCES public.medicines(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: opd_consultations opd_consultations_cancelledBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opd_consultations
    ADD CONSTRAINT "opd_consultations_cancelledBy_fkey" FOREIGN KEY ("cancelledBy") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: opd_consultations opd_consultations_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opd_consultations
    ADD CONSTRAINT "opd_consultations_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: opd_consultations opd_consultations_doctorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opd_consultations
    ADD CONSTRAINT "opd_consultations_doctorId_fkey" FOREIGN KEY ("doctorId") REFERENCES public.doctors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: opd_consultations opd_consultations_hospitalId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opd_consultations
    ADD CONSTRAINT "opd_consultations_hospitalId_fkey" FOREIGN KEY ("hospitalId") REFERENCES public.hospitals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: opd_consultations opd_consultations_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opd_consultations
    ADD CONSTRAINT "opd_consultations_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: operation_theater_revisions operation_theater_revisions_operationTheaterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_theater_revisions
    ADD CONSTRAINT "operation_theater_revisions_operationTheaterId_fkey" FOREIGN KEY ("operationTheaterId") REFERENCES public.operation_theaters(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: operation_theaters operation_theaters_assistantSurgeonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_theaters
    ADD CONSTRAINT "operation_theaters_assistantSurgeonId_fkey" FOREIGN KEY ("assistantSurgeonId") REFERENCES public.doctors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: operation_theaters operation_theaters_cancelledBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_theaters
    ADD CONSTRAINT "operation_theaters_cancelledBy_fkey" FOREIGN KEY ("cancelledBy") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: operation_theaters operation_theaters_completedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_theaters
    ADD CONSTRAINT "operation_theaters_completedBy_fkey" FOREIGN KEY ("completedBy") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: operation_theaters operation_theaters_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_theaters
    ADD CONSTRAINT "operation_theaters_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: operation_theaters operation_theaters_hospitalId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_theaters
    ADD CONSTRAINT "operation_theaters_hospitalId_fkey" FOREIGN KEY ("hospitalId") REFERENCES public.hospitals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: operation_theaters operation_theaters_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_theaters
    ADD CONSTRAINT "operation_theaters_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: operation_theaters operation_theaters_opdConsultationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_theaters
    ADD CONSTRAINT "operation_theaters_opdConsultationId_fkey" FOREIGN KEY ("opdConsultationId") REFERENCES public.opd_consultations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: operation_theaters operation_theaters_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_theaters
    ADD CONSTRAINT "operation_theaters_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: operation_theaters operation_theaters_primarySurgeonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_theaters
    ADD CONSTRAINT "operation_theaters_primarySurgeonId_fkey" FOREIGN KEY ("primarySurgeonId") REFERENCES public.doctors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: operation_theaters operation_theaters_procedureCatalogId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_theaters
    ADD CONSTRAINT "operation_theaters_procedureCatalogId_fkey" FOREIGN KEY ("procedureCatalogId") REFERENCES public.charge_catalogs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: patient_addresses patient_addresses_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_addresses
    ADD CONSTRAINT "patient_addresses_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: patient_deposit_allocations patient_deposit_allocations_depositId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_deposit_allocations
    ADD CONSTRAINT "patient_deposit_allocations_depositId_fkey" FOREIGN KEY ("depositId") REFERENCES public.patient_deposits(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: patient_deposit_allocations patient_deposit_allocations_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_deposit_allocations
    ADD CONSTRAINT "patient_deposit_allocations_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: patient_deposits patient_deposits_hospitalId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_deposits
    ADD CONSTRAINT "patient_deposits_hospitalId_fkey" FOREIGN KEY ("hospitalId") REFERENCES public.hospitals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: patient_deposits patient_deposits_opdConsultationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_deposits
    ADD CONSTRAINT "patient_deposits_opdConsultationId_fkey" FOREIGN KEY ("opdConsultationId") REFERENCES public.opd_consultations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: patient_deposits patient_deposits_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_deposits
    ADD CONSTRAINT "patient_deposits_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: patient_emergency_contacts patient_emergency_contacts_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_emergency_contacts
    ADD CONSTRAINT "patient_emergency_contacts_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: patient_referrals patient_referrals_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_referrals
    ADD CONSTRAINT "patient_referrals_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: patients patients_hospitalId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT "patients_hospitalId_fkey" FOREIGN KEY ("hospitalId") REFERENCES public.hospitals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_receivedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_receivedBy_fkey" FOREIGN KEY ("receivedBy") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: permissions permissions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT "permissions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pharmacy_invoice_items pharmacy_invoice_items_medicineId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_invoice_items
    ADD CONSTRAINT "pharmacy_invoice_items_medicineId_fkey" FOREIGN KEY ("medicineId") REFERENCES public.medicines(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pharmacy_invoice_items pharmacy_invoice_items_pharmacyInvoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_invoice_items
    ADD CONSTRAINT "pharmacy_invoice_items_pharmacyInvoiceId_fkey" FOREIGN KEY ("pharmacyInvoiceId") REFERENCES public.pharmacy_invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pharmacy_invoice_payments pharmacy_invoice_payments_pharmacyInvoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_invoice_payments
    ADD CONSTRAINT "pharmacy_invoice_payments_pharmacyInvoiceId_fkey" FOREIGN KEY ("pharmacyInvoiceId") REFERENCES public.pharmacy_invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pharmacy_invoices pharmacy_invoices_cancelledBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_invoices
    ADD CONSTRAINT "pharmacy_invoices_cancelledBy_fkey" FOREIGN KEY ("cancelledBy") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pharmacy_invoices pharmacy_invoices_hospitalId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_invoices
    ADD CONSTRAINT "pharmacy_invoices_hospitalId_fkey" FOREIGN KEY ("hospitalId") REFERENCES public.hospitals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pharmacy_invoices pharmacy_invoices_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_invoices
    ADD CONSTRAINT "pharmacy_invoices_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: pharmacy_invoices pharmacy_invoices_receivedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_invoices
    ADD CONSTRAINT "pharmacy_invoices_receivedBy_fkey" FOREIGN KEY ("receivedBy") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pharmacy_purchase_items pharmacy_purchase_items_medicineId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_purchase_items
    ADD CONSTRAINT "pharmacy_purchase_items_medicineId_fkey" FOREIGN KEY ("medicineId") REFERENCES public.medicines(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pharmacy_purchase_items pharmacy_purchase_items_purchaseOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_purchase_items
    ADD CONSTRAINT "pharmacy_purchase_items_purchaseOrderId_fkey" FOREIGN KEY ("purchaseOrderId") REFERENCES public.pharmacy_purchase_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pharmacy_purchase_orders pharmacy_purchase_orders_receivedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_purchase_orders
    ADD CONSTRAINT "pharmacy_purchase_orders_receivedBy_fkey" FOREIGN KEY ("receivedBy") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pharmacy_return_items pharmacy_return_items_medicineId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_return_items
    ADD CONSTRAINT "pharmacy_return_items_medicineId_fkey" FOREIGN KEY ("medicineId") REFERENCES public.medicines(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pharmacy_return_items pharmacy_return_items_pharmacyReturnId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_return_items
    ADD CONSTRAINT "pharmacy_return_items_pharmacyReturnId_fkey" FOREIGN KEY ("pharmacyReturnId") REFERENCES public.pharmacy_returns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pharmacy_returns pharmacy_returns_pharmacyInvoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_returns
    ADD CONSTRAINT "pharmacy_returns_pharmacyInvoiceId_fkey" FOREIGN KEY ("pharmacyInvoiceId") REFERENCES public.pharmacy_invoices(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pharmacy_stock_adjustments pharmacy_stock_adjustments_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_stock_adjustments
    ADD CONSTRAINT "pharmacy_stock_adjustments_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pharmacy_stock_adjustments pharmacy_stock_adjustments_medicineId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_stock_adjustments
    ADD CONSTRAINT "pharmacy_stock_adjustments_medicineId_fkey" FOREIGN KEY ("medicineId") REFERENCES public.medicines(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: print_histories print_histories_printedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.print_histories
    ADD CONSTRAINT "print_histories_printedById_fkey" FOREIGN KEY ("printedById") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: print_histories print_histories_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.print_histories
    ADD CONSTRAINT "print_histories_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public.print_templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: print_templates print_templates_hospitalId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.print_templates
    ADD CONSTRAINT "print_templates_hospitalId_fkey" FOREIGN KEY ("hospitalId") REFERENCES public.hospitals(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: radiology_findings_revisions radiology_findings_revisions_scanOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.radiology_findings_revisions
    ADD CONSTRAINT "radiology_findings_revisions_scanOrderId_fkey" FOREIGN KEY ("scanOrderId") REFERENCES public.radiology_scan_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: radiology_scan_orders radiology_scan_orders_ipdAdmissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.radiology_scan_orders
    ADD CONSTRAINT "radiology_scan_orders_ipdAdmissionId_fkey" FOREIGN KEY ("ipdAdmissionId") REFERENCES public.ipd_admissions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: radiology_scan_orders radiology_scan_orders_opdConsultationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.radiology_scan_orders
    ADD CONSTRAINT "radiology_scan_orders_opdConsultationId_fkey" FOREIGN KEY ("opdConsultationId") REFERENCES public.opd_consultations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: radiology_scan_orders radiology_scan_orders_orderedByDoctorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.radiology_scan_orders
    ADD CONSTRAINT "radiology_scan_orders_orderedByDoctorId_fkey" FOREIGN KEY ("orderedByDoctorId") REFERENCES public.doctors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: radiology_scan_orders radiology_scan_orders_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.radiology_scan_orders
    ADD CONSTRAINT "radiology_scan_orders_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public.patients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: radiology_scan_orders radiology_scan_orders_scanCatalogId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.radiology_scan_orders
    ADD CONSTRAINT "radiology_scan_orders_scanCatalogId_fkey" FOREIGN KEY ("scanCatalogId") REFERENCES public.radiology_scan_catalogs(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: refunds refunds_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT "refunds_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: refunds refunds_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT "refunds_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public.payments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: refunds refunds_refundedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT "refunds_refundedBy_fkey" FOREIGN KEY ("refundedBy") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sessions sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT "sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: wards wards_floorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wards
    ADD CONSTRAINT "wards_floorId_fkey" FOREIGN KEY ("floorId") REFERENCES public.floors(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT USAGE ON SCHEMA auth TO postgres;


--
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- Name: SCHEMA realtime; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA realtime TO postgres;
GRANT USAGE ON SCHEMA realtime TO anon;
GRANT USAGE ON SCHEMA realtime TO authenticated;
GRANT USAGE ON SCHEMA realtime TO service_role;
GRANT ALL ON SCHEMA realtime TO supabase_realtime_admin;


--
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA storage TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON SCHEMA storage TO dashboard_user;


--
-- Name: SCHEMA vault; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA vault TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA vault TO service_role;


--
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;


--
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO postgres;
GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;


--
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;


--
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO dashboard_user;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea, text[], text[]) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO dashboard_user;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.crypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.dearmor(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO dashboard_user;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_bytes(integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO dashboard_user;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_uuid() FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text, integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO dashboard_user;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO dashboard_user;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO dashboard_user;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_key_id(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1mc() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v4() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_nil() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_dns() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_oid() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_url() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_x500() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO dashboard_user;


--
-- Name: FUNCTION graphql("operationName" text, query text, variables jsonb, extensions jsonb); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO postgres;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO anon;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO authenticated;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO service_role;


--
-- Name: FUNCTION pg_reload_conf(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION pg_catalog.pg_reload_conf() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION get_auth(p_usename text); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION pgbouncer.get_auth(p_usename text) FROM PUBLIC;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO pgbouncer;


--
-- Name: FUNCTION apply_rls(wal jsonb, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO supabase_realtime_admin;


--
-- Name: FUNCTION broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO postgres;
GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO dashboard_user;


--
-- Name: FUNCTION build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO postgres;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO anon;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO service_role;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO supabase_realtime_admin;


--
-- Name: FUNCTION "cast"(val text, type_ regtype); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO postgres;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO dashboard_user;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO anon;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO authenticated;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO service_role;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO supabase_realtime_admin;


--
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO service_role;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO supabase_realtime_admin;


--
-- Name: FUNCTION is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO postgres;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO anon;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO service_role;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO supabase_realtime_admin;


--
-- Name: FUNCTION list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO dashboard_user;


--
-- Name: FUNCTION quote_wal2json(entity regclass); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO postgres;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO anon;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO authenticated;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO service_role;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO supabase_realtime_admin;


--
-- Name: FUNCTION send(payload jsonb, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO dashboard_user;


--
-- Name: FUNCTION send_binary(payload bytea, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) TO dashboard_user;


--
-- Name: FUNCTION subscription_check_filters(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO postgres;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO dashboard_user;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO anon;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO authenticated;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO service_role;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO supabase_realtime_admin;


--
-- Name: FUNCTION to_regrole(role_name text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO postgres;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO anon;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO authenticated;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO service_role;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO supabase_realtime_admin;


--
-- Name: FUNCTION topic(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.topic() TO postgres;
GRANT ALL ON FUNCTION realtime.topic() TO dashboard_user;


--
-- Name: FUNCTION wal2json_escape_identifier(name text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.wal2json_escape_identifier(name text) TO postgres;
GRANT ALL ON FUNCTION realtime.wal2json_escape_identifier(name text) TO dashboard_user;


--
-- Name: FUNCTION _crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO service_role;


--
-- Name: FUNCTION create_secret(new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: FUNCTION update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.audit_log_entries TO postgres;
GRANT SELECT ON TABLE auth.audit_log_entries TO postgres WITH GRANT OPTION;


--
-- Name: TABLE custom_oauth_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.custom_oauth_providers TO postgres;
GRANT ALL ON TABLE auth.custom_oauth_providers TO dashboard_user;


--
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.flow_state TO postgres;
GRANT SELECT ON TABLE auth.flow_state TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.flow_state TO dashboard_user;


--
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.identities TO postgres;
GRANT SELECT ON TABLE auth.identities TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.identities TO dashboard_user;


--
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.instances TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.instances TO postgres;
GRANT SELECT ON TABLE auth.instances TO postgres WITH GRANT OPTION;


--
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_amr_claims TO postgres;
GRANT SELECT ON TABLE auth.mfa_amr_claims TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_amr_claims TO dashboard_user;


--
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_challenges TO postgres;
GRANT SELECT ON TABLE auth.mfa_challenges TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_challenges TO dashboard_user;


--
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_factors TO postgres;
GRANT SELECT ON TABLE auth.mfa_factors TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_factors TO dashboard_user;


--
-- Name: TABLE oauth_authorizations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_authorizations TO postgres;
GRANT ALL ON TABLE auth.oauth_authorizations TO dashboard_user;


--
-- Name: TABLE oauth_client_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_client_states TO postgres;
GRANT ALL ON TABLE auth.oauth_client_states TO dashboard_user;


--
-- Name: TABLE oauth_clients; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_clients TO postgres;
GRANT ALL ON TABLE auth.oauth_clients TO dashboard_user;


--
-- Name: TABLE oauth_consents; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_consents TO postgres;
GRANT ALL ON TABLE auth.oauth_consents TO dashboard_user;


--
-- Name: TABLE one_time_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.one_time_tokens TO postgres;
GRANT SELECT ON TABLE auth.one_time_tokens TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.one_time_tokens TO dashboard_user;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.refresh_tokens TO postgres;
GRANT SELECT ON TABLE auth.refresh_tokens TO postgres WITH GRANT OPTION;


--
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_providers TO postgres;
GRANT SELECT ON TABLE auth.saml_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_providers TO dashboard_user;


--
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_relay_states TO postgres;
GRANT SELECT ON TABLE auth.saml_relay_states TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_relay_states TO dashboard_user;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE auth.schema_migrations TO postgres WITH GRANT OPTION;


--
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sessions TO postgres;
GRANT SELECT ON TABLE auth.sessions TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sessions TO dashboard_user;


--
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_domains TO postgres;
GRANT SELECT ON TABLE auth.sso_domains TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_domains TO dashboard_user;


--
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_providers TO postgres;
GRANT SELECT ON TABLE auth.sso_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_providers TO dashboard_user;


--
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.users TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.users TO postgres;
GRANT SELECT ON TABLE auth.users TO postgres WITH GRANT OPTION;


--
-- Name: TABLE webauthn_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.webauthn_challenges TO postgres;
GRANT ALL ON TABLE auth.webauthn_challenges TO dashboard_user;


--
-- Name: TABLE webauthn_credentials; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.webauthn_credentials TO postgres;
GRANT ALL ON TABLE auth.webauthn_credentials TO dashboard_user;


--
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements TO dashboard_user;


--
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements_info FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO dashboard_user;


--
-- Name: TABLE messages; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE realtime.messages TO postgres;
GRANT ALL ON TABLE realtime.messages TO dashboard_user;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO anon;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO authenticated;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO service_role;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.schema_migrations TO postgres;
GRANT ALL ON TABLE realtime.schema_migrations TO dashboard_user;
GRANT SELECT ON TABLE realtime.schema_migrations TO anon;
GRANT SELECT ON TABLE realtime.schema_migrations TO authenticated;
GRANT SELECT ON TABLE realtime.schema_migrations TO service_role;
GRANT ALL ON TABLE realtime.schema_migrations TO supabase_realtime_admin;


--
-- Name: TABLE subscription; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.subscription TO postgres;
GRANT ALL ON TABLE realtime.subscription TO dashboard_user;
GRANT SELECT ON TABLE realtime.subscription TO anon;
GRANT SELECT ON TABLE realtime.subscription TO authenticated;
GRANT SELECT ON TABLE realtime.subscription TO service_role;
GRANT ALL ON TABLE realtime.subscription TO supabase_realtime_admin;


--
-- Name: SEQUENCE subscription_id_seq; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO postgres;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO dashboard_user;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO anon;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO authenticated;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO service_role;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO supabase_realtime_admin;


--
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE storage.buckets FROM supabase_storage_admin;
GRANT ALL ON TABLE storage.buckets TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON TABLE storage.buckets TO service_role;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.buckets TO anon;
GRANT ALL ON TABLE storage.buckets TO postgres WITH GRANT OPTION;


--
-- Name: TABLE buckets_analytics; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets_analytics TO service_role;
GRANT ALL ON TABLE storage.buckets_analytics TO authenticated;
GRANT ALL ON TABLE storage.buckets_analytics TO anon;


--
-- Name: TABLE buckets_vectors; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE storage.buckets_vectors TO service_role;
GRANT SELECT ON TABLE storage.buckets_vectors TO authenticated;
GRANT SELECT ON TABLE storage.buckets_vectors TO anon;


--
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE storage.objects FROM supabase_storage_admin;
GRANT ALL ON TABLE storage.objects TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON TABLE storage.objects TO service_role;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT ALL ON TABLE storage.objects TO anon;
GRANT ALL ON TABLE storage.objects TO postgres WITH GRANT OPTION;


--
-- Name: TABLE s3_multipart_uploads; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO anon;


--
-- Name: TABLE s3_multipart_uploads_parts; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads_parts TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO anon;


--
-- Name: TABLE vector_indexes; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE storage.vector_indexes TO service_role;
GRANT SELECT ON TABLE storage.vector_indexes TO authenticated;
GRANT SELECT ON TABLE storage.vector_indexes TO anon;


--
-- Name: TABLE secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.secrets TO service_role;


--
-- Name: TABLE decrypted_secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.decrypted_secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.decrypted_secrets TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON TABLES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO service_role;


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO supabase_admin;

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO supabase_admin;

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO supabase_admin;

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO supabase_admin;

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO supabase_admin;

--
-- PostgreSQL database dump complete
--

\unrestrict jpnQ70rIrJsc8zlNp1kupkjPajocqWfJIuR6XdxpgwIkDbtsvDLN6IftQxM1nch

